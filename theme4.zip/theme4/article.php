<?php
require_once __DIR__ . '/includes/articles-data.php';
require_once __DIR__ . '/includes/functions.php';

// Select article or micro-lesson
$slug = $_GET['slug'] ?? 'temperaturnye-profili';
$tchp_home = function_exists('home_url') ? home_url('/') : 'https://tochka-plavleniya.ru/';
$tchp_article_canonical = function_exists('home_url')
    ? home_url('/' . rawurlencode($slug) . '/')
    : 'article.php?slug=' . urlencode($slug);
$lesson = get_lesson_by_slug($slug);
$article = get_article_by_slug($slug);
if (!$article && !$lesson) { 
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}
if (!$article && $lesson) {
    $article = [
        'slug' => $lesson['slug'] ?? $slug,
        'title' => $lesson['title'],
        'excerpt' => ($lesson['subtitle'] ?? '') . ' — ' . ($lesson['tldr'] ?? ''),
        'date' => '10 авг 2026',
        'author' => 'ТОЧКА ПЛАВЛЕНИЯ',
        'read_time' => ($lesson['read_min'] ?? 5) . ' мин',
        'tag' => 'Микроурок',
        'tag_key' => 'uroki'
    ];
}

// Related articles (pick 3 other articles)
$related_articles = array_filter($articles, function($item) use ($article) {
    return ($item['slug'] ?? '') !== ($article['slug'] ?? '');
});
$related_articles = array_slice($related_articles, 0, 3);

// FAQ data for Schema.org & Accordion
if ($lesson && !empty($lesson['faq'])) {
    $faq_items = $lesson['faq'];
    $page_title = $lesson['title'] . ' // Микроурок (' . $lesson['read_min'] . ' мин) — ТОЧКА ПЛАВЛЕНИЯ';
    $page_desc = $lesson['subtitle'] . ' — ' . $lesson['tldr'];
} else {
    $faq_items = [
        "Какая максимальная температура допустима для бессвинцовой пайки BGA?" => "По стандарту IPC/JEDEC J-STD-020D абсолютный пиковый предел для большинства полупроводниковых BGA-корпусов составляет 250°C (не более 10 секунд). Оптимальный рабочий пик оплавления — ровно 238–242°C.",
        "Сколько секунд припой должен находиться в расплавленном состоянии (TAL)?" => "Время над ликвидусом (TAL) для сплава SAC305 (217°C) должно составлять от 45 до 75 секунд. Если TAL меньше 40 с — возможны непропаи («холодная пайка»). Если дольше 90 с — интерметаллический слой становится слишком толстым и хрупким, контакт отрывается при вибрации.",
        "Как избежать эффекта 'попкорна' при пайке влажных микросхем?" => "Храните чипы в заводских вакуумных влагозащитных пакетах с индикатором влажности. Если пакет вскрыт, поместите микросхемы в конвекционную печь при 100–110°C на 12–24 часа до пайки.",
        "Какой флюс использовать для реболлинга BGA: RMA или No-Clean?" => "Для реболлинга шаров рекомендуется канифольный среднеактивированный флюс (RMA или безотмывочный ROL0 с высокой вязкостью). Подложки BGA требуют тщательной промывки изопропанолом или спецраствором в ультразвуковой ванне после посадки."
    ];
    $page_title = $article['title'] . ' — ТОЧКА ПЛАВЛЕНИЯ';
    $page_desc = $article['excerpt'];
}
$current_page = 'article';
ob_start();
?>
<?php $assets_base = function_exists('get_template_directory_uri') ? get_template_directory_uri() : ''; ?>
<!-- Design Tokens & Article Styles -->
<link rel="stylesheet" href="<?= $assets_base ?>/assets/css/tokens.css"/>
<link rel="stylesheet" href="<?= $assets_base ?>/assets/css/fonts.css"/>
<link rel="stylesheet" href="<?= $assets_base ?>/assets/css/build.css"/>
<link rel="stylesheet" href="<?= $assets_base ?>/assets/css/base.css"/>
<link rel="stylesheet" href="<?= $assets_base ?>/assets/css/article.css"/>

<style>
  /* Hand-drawn marker underline */
  .marker-underline {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 12' preserveAspectRatio='none'%3E%3Cpath d='M1 8 C 25 3, 60 10, 99 5 C 75 11, 30 7, 2 10 Z' fill='%23facc15' fill-opacity='0.85'/%3E%3C/svg%3E");
    background-position: 0 100%;
    background-size: 100% 0.35em;
    background-repeat: no-repeat;
    padding-bottom: 0.1em;
  }

  .custom-scrollbar::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }
  .custom-scrollbar::-webkit-scrollbar-thumb {
    background: var(--color-paper-border-dark);
    border-radius: var(--radius-sm);
  }

  /* Safety & Caution Callouts (Safety First for DIY & High Voltage) */
  .callout-safety {
    border: 1px solid var(--color-danger-border);
    background: var(--color-danger-bg);
    border-radius: var(--radius-md);
    padding: 1rem 1.25rem;
    margin: 1.5rem 0;
    color: var(--color-danger);
  }
  .callout-safety strong {
    color: var(--color-danger);
  }
  html.dark .callout-safety {
    border-color: var(--color-danger-border);
    border-left-color: var(--color-accent);
    background: var(--color-danger-bg);
    color: var(--color-danger);
  }
  html.dark .callout-safety strong {
    color: var(--color-danger);
  }

  /* Responsive BOM / Data Tables for DIY Articles */
  .prose table,
  .bom-table {
    width: 100%;
    border-collapse: collapse;
    font-size: var(--text-sm);
    margin: 1.5rem 0;
    text-align: left;
    border: 1px solid var(--color-paper-border);
    border-radius: var(--radius-md);
    overflow: hidden;
  }
  .prose thead th,
  .bom-table th {
    background: var(--color-paper-subtle);
    padding: 0.65rem 0.85rem;
    font-family: var(--font-mono, monospace);
    font-size: var(--text-stamp);
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--color-ink);
    border-bottom: 2px solid var(--color-paper-border-dark);
  }
  .prose td,
  .bom-table td {
    padding: 0.65rem 0.85rem;
    border-bottom: 1px solid var(--color-paper-border);
    color: var(--color-ink-muted);
  }
  .prose tr:last-child td,
  .bom-table tr:last-child td {
    border-bottom: none;
  }
  .prose tr:hover td,
  .bom-table tr:hover td {
    background: rgba(0, 0, 0, 0.02);
  }
  html.dark .prose tr:hover td,
  html.dark .bom-table tr:hover td {
    background: rgba(255, 255, 255, 0.03);
  }
  .table-responsive {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    margin: 1.5rem 0;
  }

  /* Responsive video player embeds (VK Видео / RuTube / WebM) */
  .prose iframe,
  .prose video {
    width: 100%;
    max-width: 100%;
    aspect-ratio: 16 / 9;
    border-radius: 8px;
    border: 1px solid var(--color-paper-border);
  }
</style>

<!-- Canonical URL -->
<?php if (!defined('RANK_MATH_VERSION')): ?><link rel="canonical" href="<?= htmlspecialchars($tchp_article_canonical, ENT_QUOTES, 'UTF-8') ?>"/><?php endif; ?>

<!-- Schema.org JSON-LD -->
<?= render_article_schema($article, $faq_items) ?>
<?php
$extra_head = ob_get_clean();
include __DIR__ . '/includes/header.php';
?>
<!-- Reading Progress Bar (Solder Ribbon) -->
<div id="reading-progress-bar" aria-hidden="true"></div>

<!-- CAD Ruler Sidelines (visible > 1320px) -->
<div class="hidden xl:flex cad-ruler-track left" aria-hidden="true">
  <span>0 mm</span>
  <span>50</span>
  <span>100 mm</span>
  <span>150</span>
  <span>200 mm</span>
  <span>250</span>
  <span>300 mm</span>
  <span>350</span>
  <span>400 mm</span>
</div>
<div class="hidden xl:flex cad-ruler-track right" aria-hidden="true">
  <span>[SEC.01]</span>
  <span>• • •</span>
  <span>[IPC-610]</span>
  <span>• • •</span>
  <span>[TOL ±0.5]</span>
  <span>• • •</span>
  <span>[QC-PASS]</span>
</div>

<!-- Main Container -->
<main class="w-full flex-grow pt-8 pb-20 cad-blueprint-canvas relative" id="main-content">
  <div class="max-w-[1140px] mx-auto px-5 sm:px-8">
    
    <!-- Breadcrumbs -->
    <nav class="text-xs font-mono text-ink-faint mb-8 flex items-center gap-1.5 flex-wrap" aria-label="Хлебные крошки">
      <a class="hover:text-ink transition-colors" href="index.php">Главная</a>
      <span>→</span>
      <?php if (!empty($lesson)): ?>
        <a class="hover:text-ink transition-colors" href="index.php#lessons">Микроуроки</a>
        <span>→</span>
        <span class="text-ink truncate max-w-xs sm:max-w-md"><?= e($lesson['title']) ?></span>
      <?php else: ?>
        <a class="hover:text-ink transition-colors" href="index.php?tag=<?= e($article['tag_key'] ?? 'bga') ?>">Гайды</a>
        <span>→</span>
        <span class="text-ink truncate max-w-xs sm:max-w-md"><?= e($article['title']) ?></span>
      <?php endif; ?>
    </nav>


    <!-- Center Article + Table of Contents Layout -->
    <div class="relative grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-start">
      
      <!-- Central Editorial Column (740px wide max) -->
      <div class="lg:col-span-8 max-w-[730px] space-y-5">
        
        <!-- Article Header Card (Playdate 1-bit tactile styling with CAD corner marks) -->
        <div class="playdate-card cad-corner-marks p-5 sm:p-8 space-y-5 rounded">

          <!-- Header Stamp & Technical Spec Bar -->
          <div class="flex items-center justify-between pb-3 border-b border-paper-border text-xs font-mono">
            <div class="flex items-center gap-2">
              <div class="w-7 h-7 rounded border border-paper-border bg-paper-subtle flex items-center justify-center text-ink shrink-0 shadow-xs">
                <?= tp_icon('wrench', 'w-4 h-4 text-accent') ?>
              </div>
              <span class="font-bold text-ink uppercase tracking-wider">ТЕХРЕГЛАМЕНТ // ОТК-2026</span>
            </div>
            <div class="flex items-center gap-2">
              <button type="button" onclick="window.print()" class="no-print hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded border border-paper-border bg-paper hover:bg-paper-subtle text-ink-muted hover:text-ink text-stamp font-mono font-medium transition-colors cursor-pointer" title="Распечатать технологическую карту (Ctrl+P)">
                <?= tp_icon('printer', 'w-3.5 h-3.5') ?>
                <span>Печать техкарты</span>
              </button>
              <span class="font-mono text-stamp font-bold uppercase px-2 py-0.5 rounded border border-paper-border bg-paper-subtle text-ink">
                IPC-A-610G // КЛАСС 2
              </span>
            </div>
          </div>

          <!-- Article Header Block -->
          <header class="space-y-4">
            <h1 class="text-3xl sm:text-4xl font-bold text-ink tracking-[-0.03em] leading-[1.18] font-sans">
              <?= e($lesson ? $lesson['title'] : $article['title']) ?>
            </h1>

            <!-- Meta line -->
            <div class="flex flex-wrap items-center gap-x-2.5 gap-y-1.5 text-xs text-ink-muted font-mono pt-1 pb-2 border-b border-paper-border/60">
              <div class="flex items-center gap-2">
                <span class="w-5 h-5 rounded-full border border-paper-border bg-paper-subtle text-stamp flex items-center justify-center font-bold text-ink">ТП</span>
                <span class="text-ink"><?= e($lesson ? $lesson['author'] : ($article['author'] ?? 'Инженер Лаборатории ТЧП')) ?></span>
              </div>
              <span class="hidden sm:inline text-ink-faint" aria-hidden="true">·</span>
              <time datetime="<?= e($lesson ? $lesson['date'] : ($article['date'] ?? '2026-08-20')) ?>"><?= e($lesson ? $lesson['date'] : ($article['date'] ?? '20 августа 2026')) ?></time>
              <span class="hidden sm:inline text-ink-faint" aria-hidden="true">·</span>
              <span class="flex items-center gap-1"><?= tp_icon('clock', 'w-3.5 h-3.5') ?>~<?= e($lesson ? $lesson['read_min'] : ($article['read_min'] ?? 8)) ?> мин чтения</span>
              <span class="hidden sm:inline text-ink-faint" aria-hidden="true">·</span>
              <span class="flex items-center gap-1"><?= tp_icon('graduation-cap', 'w-3.5 h-3.5') ?>Уровень: <?= e($lesson ? $lesson['difficulty'] : ($article['difficulty'] ?? 'Инженер')) ?></span>
              <span class="hidden sm:inline text-ink-faint" aria-hidden="true">·</span>
              <span class="flex items-center gap-1 text-emerald-600 dark:text-emerald-500 font-bold" title="Регламент соответствует стандарту IPC J-STD"><?= tp_icon('shield-check', 'w-3.5 h-3.5') ?>Проверено</span>
            </div>

            <!-- Adafruit / SparkFun Quick-Spec Passport Bar -->
            <div class="quick-spec-passport">
              <div class="passport-col">
                <span class="passport-label">ТЕМПЕРАТУРА ЖАЛА</span>
                <div class="te-display">
                  <span class="te-ghost">888 °C</span>
                  <span class="te-active">275 °C</span>
                </div>
              </div>
              <div class="passport-col">
                <span class="passport-label">СПЛАВ ПРИПОЯ</span>
                <span class="passport-value text-accent">ПОС-61 / SAC305</span>
              </div>
              <div class="passport-col">
                <span class="passport-label">ВРЕМЯ КОНТАКТА (TAL)</span>
                <span class="passport-value">&lt; 2.5 сек</span>
              </div>
              <div class="passport-col">
                <span class="passport-label">КЛАСС ОТМЫВКИ</span>
                <span class="passport-value text-emerald-600 dark:text-emerald-400">ROL0 / No-Clean</span>
              </div>
            </div>

            <?php if (!empty($lesson)): ?>
            <div class="mt-2 flex flex-wrap items-center gap-2 text-xs font-mono">
              <span class="text-ink-muted">Оснастка:</span>
              <?php foreach (array_keys($lesson['required_tools']) as $tool): ?>
                <span class="bg-paper-subtle px-1.5 py-0.5 rounded border border-paper-border text-ink"><?= e($tool) ?></span>
              <?php endforeach; ?>
            </div>
            <?php elseif (!empty($article['required_tools'])): ?>
            <div class="mt-2 flex flex-wrap items-center gap-2 text-xs font-mono">
              <span class="text-ink-muted">Понадобится:</span>
              <?php foreach ($article['required_tools'] as $tool): ?>
                <span class="bg-paper-subtle px-1.5 py-0.5 rounded border border-paper-border text-ink"><?= e($tool) ?></span>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Lead Paragraph -->
            <p class="text-lg text-ink font-serif leading-[1.65] pt-2">
              <?= e($lesson ? $lesson['subtitle'] : $article['excerpt']) ?><?php if ($slug === 'temperaturnye-profili'): ?> Разбираем, почему стандартная пайка «по цифрам на табло фена» гарантированно убивает многослойные платы, как выставить 4 фазы термопрофиля по стандарту IPC/JEDEC и не допустить коробления текстолита.<?php endif; ?>
            </p>
          </header>

        </div><!-- /Article Header Card -->

        <?php if (!empty($lesson)): ?>
        <!-- MICRO-LESSON COMPLETE APPLIED REGULATION -->

        <!-- 1. TL;DR Rule Card -->
        <div class="p-5 rounded-lg border border-paper-border bg-paper-subtle space-y-2.5 shadow-xs">
          <div class="flex items-center gap-2">
            <svg class="w-4 h-4 text-accent inline-block shrink-0" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            <span class="font-mono text-xs font-bold uppercase tracking-wider text-ink">ГЛАВНЫЙ ИНЖЕНЕРНЫЙ ПРИНЦИП // 10 СЕКУНД</span>
          </div>
          <p class="text-sm sm:text-base font-sans font-medium text-ink leading-relaxed">
            <?= e($lesson['tldr']) ?>
          </p>
        </div>

        <!-- 2. Technical Map & Tools -->
        <section class="bg-paper border border-paper-border rounded-lg p-5 sm:p-6 space-y-4 shadow-sm">
          <div class="flex items-center justify-between pb-3 border-b border-paper-border flex-wrap gap-2">
            <div class="flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-accent inline-block"></span>
              <h2 class="text-base sm:text-lg font-bold font-mono uppercase tracking-tight text-ink">Технологическая карта и оснастка</h2>
            </div>
            <span class="text-xs font-mono text-ink-muted">IPC-A-610 / ГОСТ</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <!-- Оснастка и инструмент -->
            <div class="p-4 rounded-lg bg-paper-subtle border border-paper-border space-y-2.5">
              <div class="text-stamp font-mono font-bold uppercase tracking-wider text-ink pb-1.5 border-b border-paper-border flex items-center justify-between">
                <span>Инструмент и материалы</span>
                <span class="text-accent text-stamp font-bold">SPECS</span>
              </div>
              <dl class="space-y-2 text-xs font-mono">
                <?php foreach ($lesson['required_tools'] as $tool_name => $tool_desc): ?>
                  <div class="flex flex-col sm:flex-row sm:justify-between gap-0.5">
                    <dt class="text-ink-muted"><?= e($tool_name) ?>:</dt>
                    <dd class="font-bold text-ink sm:text-right"><?= e($tool_desc) ?></dd>
                  </div>
                <?php endforeach; ?>
              </dl>
            </div>

            <!-- Режимы и допуски -->
            <div class="p-4 rounded-lg bg-paper-subtle border border-paper-border space-y-2.5">
              <div class="text-stamp font-mono font-bold uppercase tracking-wider text-ink pb-1.5 border-b border-paper-border flex items-center justify-between">
                <span>Параметры техпроцесса</span>
                <span class="text-emerald-600 dark:text-emerald-400 text-stamp font-bold">TOLERANCE</span>
              </div>
              <dl class="space-y-2 text-xs font-mono">
                <?php foreach ($lesson['key_specs'] as $spec_name => $spec_val): ?>
                  <div class="flex flex-col sm:flex-row sm:justify-between gap-0.5">
                    <dt class="text-ink-muted"><?= e($spec_name) ?>:</dt>
                    <dd class="font-bold text-ink sm:text-right"><?= e($spec_val) ?></dd>
                  </div>
                <?php endforeach; ?>
              </dl>
            </div>
          </div>
        </section>

        <!-- 3. Step-by-Step Procedure -->
        <section class="space-y-4">
          <div class="flex items-center justify-between">
            <h2 class="text-xl sm:text-2xl font-bold font-sans text-ink tracking-tight">Пошаговый регламент операции</h2>
            <span class="font-mono text-xs text-ink-muted"><?= count($lesson['steps']) ?> шага</span>
          </div>

          <div class="space-y-3">
            <?php foreach ($lesson['steps'] as $st): ?>
              <div class="p-5 rounded-lg border border-paper-border bg-paper space-y-2 shadow-sm">
                <div class="flex items-center gap-2.5">
                  <span class="w-6 h-6 rounded border border-paper-border-dark bg-paper-subtle text-xs font-mono font-bold flex items-center justify-center text-ink shrink-0"><?= $st['num'] ?></span>
                  <h3 class="text-base font-bold font-sans text-ink"><?= e($st['title']) ?></h3>
                </div>
                <p class="text-sm font-serif text-ink/85 leading-relaxed pl-8">
                  <?= e($st['desc']) ?>
                </p>
              </div>
            <?php endforeach; ?>
          </div>
        </section>

        <!-- 4. Danger Rule Block (Authentic Pencil Shading) -->
        <div class="box-caution-orange relative p-5 rounded-lg shadow-xs space-y-3 sketch-pencil-orange">
          <div class="flex items-center justify-between font-mono text-xs font-bold">
            <span class="flex items-center gap-1.5 text-[#d35400] dark:text-[#f39c12]">
              <svg class="w-4 h-4 stroke-current inline-block shrink-0" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              КАТЕГОРИЧЕСКИ ЗАПРЕЩЕНО // ОПАСНОСТЬ БРАКА
            </span>
            <span class="px-2 py-0.5 text-stamp bg-paper text-ink border border-paper-border-dark rounded font-bold uppercase">СТОП</span>
          </div>
          <h3 class="font-mono text-sm font-bold text-ink">
            <?= e($lesson['danger_rule']['title']) ?>
          </h3>
          <p class="font-sans text-xs sm:text-sm text-ink leading-relaxed">
            <?= e($lesson['danger_rule']['text']) ?>
          </p>
          <div class="font-hand text-base text-ink-muted italic pt-1 border-t border-paper-border/60">
            <?= e($lesson['danger_rule']['hand']) ?>
          </div>
        </div>

        <!-- 5. Interactive Checklist Card -->
        <section class="bg-paper border border-paper-border rounded-lg p-5 sm:p-6 space-y-4 shadow-sm" id="lesson-checklist-section">
          <div class="flex items-center justify-between flex-wrap gap-2 pb-3 border-b border-paper-border">
            <div class="flex items-center gap-2">
              <svg class="w-4 h-4 text-accent inline-block shrink-0" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
              <h2 class="text-base sm:text-lg font-bold font-mono uppercase tracking-tight text-ink">Чек-лист готовности и контроля</h2>
            </div>
            <div class="text-xs font-mono text-ink-muted">
              Прогресс: <span id="lesson-check-counter" class="font-bold text-accent">0/<?= count($lesson['checklist']) ?></span>
            </div>
          </div>

          <div class="space-y-2.5">
            <?php foreach ($lesson['checklist'] as $idx => $chk_item): ?>
              <label class="flex items-start gap-3 p-3 rounded-lg border border-paper-border bg-paper-subtle hover:bg-paper cursor-pointer transition-all select-none">
                <input type="checkbox" 
                       class="lesson-step-checkbox mt-0.5 w-4 h-4 rounded border-paper-border-dark text-accent focus:ring-0 cursor-pointer"
                       data-lesson-slug="<?= e($lesson['slug']) ?>"
                       data-check-index="<?= $idx ?>">
                <span class="text-xs sm:text-sm font-mono text-ink leading-normal flex-1 check-text">
                  <?= e($chk_item) ?>
                </span>
              </label>
            <?php endforeach; ?>
          </div>
        </section>

        <!-- 6. Workbench Calculator Callout -->
        <div class="p-5 rounded-lg border border-paper-border bg-paper-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
          <div class="space-y-1">
            <div class="font-mono text-xs font-bold uppercase tracking-wider text-accent flex items-center gap-1.5">
              <?= tp_icon('wrench', 'w-4 h-4 text-accent') ?>
              <span>Интерактивный верстак ТЧП</span>
            </div>
            <h3 class="text-base sm:text-lg font-bold text-ink">Рассчитайте параметры для вашей задачи</h3>
            <p class="text-xs sm:text-sm text-ink-muted">Используйте калькуляторы верстака для мгновенного подбора флюса, жала и расхода припоя.</p>
          </div>
          <a href="<?= e($lesson['interactive_link']['url']) ?>" class="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded bg-ink hover:bg-ink-muted text-paper text-xs font-mono font-bold transition-colors shadow-sm shrink-0 sm:whitespace-nowrap text-center">
            <span><?= e($lesson['interactive_link']['label']) ?></span>
            <?= tp_icon('arrow-right', 'w-4 h-4') ?>
          </a>
        </div>

        <!-- 7. FAQ Accordion / Cards -->
        <?php if (!empty($lesson['faq'])): ?>
        <section class="bg-paper border border-paper-border rounded-lg p-5 sm:p-6 space-y-4 shadow-sm" id="lesson-faq">
          <div class="flex items-center gap-2 pb-3 border-b border-paper-border">
            <?= tp_icon('alert-triangle', 'w-5 h-5 text-accent') ?>
            <h2 class="text-base sm:text-lg font-bold font-mono uppercase tracking-tight text-ink">Частые вопросы по регламенту</h2>
          </div>

          <div class="space-y-3">
            <?php foreach ($lesson['faq'] as $question => $answer): ?>
              <div class="p-4 rounded-lg bg-paper-subtle border border-paper-border space-y-1.5">
                <h3 class="font-mono text-xs sm:text-sm font-bold text-ink flex items-start gap-2">
                  <span class="text-accent font-bold">В:</span>
                  <span><?= e($question) ?></span>
                </h3>
                <p class="font-serif text-xs sm:text-sm text-ink-muted leading-relaxed pl-5">
                  <?= e($answer) ?>
                </p>
              </div>
            <?php endforeach; ?>
          </div>
        </section>
        <?php endif; ?>

        <!-- Script for Interactive Checklist state -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
          const checkboxes = document.querySelectorAll('.lesson-step-checkbox');
          const counter = document.getElementById('lesson-check-counter');
          const sidebarStatus = document.getElementById('sidebar-check-status');
          if (!checkboxes.length) return;

          const slug = checkboxes[0].dataset.lessonSlug;
          const storageKey = 'tp_lesson_chk_' + slug;

          function loadSaved() {
            try {
              const saved = JSON.parse(localStorage.getItem(storageKey) || '[]');
              checkboxes.forEach((cb, idx) => {
                if (saved.includes(idx)) {
                  cb.checked = true;
                  const textEl = cb.closest('label').querySelector('.check-text');
                  if (textEl) textEl.classList.add('line-through', 'text-ink-muted');
                }
              });
              updateCount();
            } catch (e) {}
          }

          function updateCount() {
            const checked = Array.from(checkboxes).filter(cb => cb.checked).length;
            const total = checkboxes.length;
            if (counter) counter.textContent = checked + '/' + total;
            if (sidebarStatus) sidebarStatus.textContent = checked + '/' + total + ' выполнено';
            
            const checkedIndices = Array.from(checkboxes)
              .map((cb, idx) => cb.checked ? idx : null)
              .filter(idx => idx !== null);
            localStorage.setItem(storageKey, JSON.stringify(checkedIndices));
          }

          checkboxes.forEach(cb => {
            cb.addEventListener('change', function() {
              const textEl = this.closest('label').querySelector('.check-text');
              if (textEl) {
                if (this.checked) {
                  textEl.classList.add('line-through', 'text-ink-muted');
                } else {
                  textEl.classList.remove('line-through', 'text-ink-muted');
                }
              }
              updateCount();
            });
          });

          loadSaved();
        });
        </script>
        <!-- /MICRO-LESSON -->

        <?php elseif ($slug === 'temperaturnye-profili'): ?>
        <!-- Callout: "Как читать этот регламент" (tochkicamp style box) -->
        <div class="border border-paper-border bg-paper-subtle/50 p-5 rounded-lg text-sm leading-relaxed space-y-2">

          <div class="text-stamp font-mono font-semibold uppercase tracking-wider text-ink">
            КАК ЧИТАТЬ ЭТОТ РЕГЛАМЕНТ
          </div>
          <p class="text-ink/80">
            Если вы настраиваете термопрофиль под конкретный чип, сразу переходите к <a class="underline decoration-amber-500/50 underline-offset-2 hover:decoration-amber-700 text-amber-700 dark:text-amber-400 font-medium transition-colors" href="#simulator">симулятору 4 фаз</a> или <a class="underline decoration-amber-500/50 underline-offset-2 hover:decoration-amber-700 text-amber-700 dark:text-amber-400 font-medium transition-colors" href="#alloys">температурным окнам сплавов</a>. Все значения температур верифицированы контактными термопарами К-типа.
          </p>
        </div>

        <!-- TL;DR Sticky Post-It Note (Yellow with dark mode parity) -->
        <div class="postit-yellow p-5 rounded-lg relative my-6">
          <div class="flex items-center gap-2 mb-2">
            <?= tp_icon('pin', 'w-5 h-5 text-accent') ?>
            <h3 class="font-hand text-2xl font-bold text-ink">В двух словах (TL;DR)</h3>
          </div>
          <p class="text-base leading-relaxed text-ink/90">
            <strong>Ключевая мысль:</strong> Нагрев должен быть двухсторонним (нижний подогрев 140–160°C обязателен). Без нижнего подогрева верхний фен перегревает чип до деструкции кремния, пока нижние слои меди остаются холодными.
          </p>
        </div>

        <!-- Section 1 -->
        <section class="scroll-mt-20 bg-paper border border-paper-border rounded-lg p-5 sm:p-6 space-y-4 shadow-sm" id="step-1">
          <h2 class="text-xl sm:text-2xl font-bold text-ink tracking-tight">
            1. Теплоемкость текстолита и почему фен всегда врет
          </h2>
          <p class="text-ink/85">
            Стандартная ошибка при пайке сложных чипов — выставлять на станции фиксированные 350°C и греть плату сверху. Датчик станции измеряет температуру спирали внутри фена, а на поверхности текстолита и тем более под корпусом BGA температура оказывается <strong>на 80–120°C ниже</strong>.
          </p>
          
          <!-- Inline quote/highlight line -->
          <div class="relative border border-paper-border bg-paper-subtle/70 px-5 py-3.5 my-4 rounded-lg shadow-xs">
            <div class="text-lg sm:text-xl font-serif italic text-ink leading-relaxed tracking-[-0.01em]">«Температура на сопле фена не имеет ничего общего с температурой припоя под чипом. Без замера на плате вы паяете вслепую».</div>
            <div class="mt-2 font-serif italic text-xs text-ink-muted flex items-center gap-1.5"><span class="font-mono not-italic text-xs text-ink">—</span> заметка на полях лабораторного журнала</div>
          </div>

          <p class="text-ink/85">
            Плата состоит из 6–12 слоев FR-4 и сплошных полигонов питания/земли (GND). Медь моментально отводит тепло от точки нагрева. Попытка прогреть только верх чипа создает мощный тепловой градиент: текстолит изгибается «лодочкой» (<span class="font-mono text-xs bg-paper-subtle px-1 rounded">warpage</span>), а центральные шарики слипаются в короткое замыкание.
          </p>

          <!-- Рис. 1: Эскиз термического градиента -->
          <figure class="my-6 rounded-lg border border-paper-border-dark bg-white/80 dark:bg-card p-2.5 sm:p-3 shadow-sm space-y-2.5">
            <div class="overflow-hidden rounded border border-paper-border bg-white dark:bg-paper">
              <img src="<?= $assets_base ?>/assets/schematics/thermal-gradient.svg" alt="Схема термического градиента при локальном нагреве соплом фена" class="w-full h-auto block object-contain">
            </div>
            <figcaption class="px-1 text-xs font-mono text-ink-muted leading-relaxed flex items-center justify-between">
              <span><span class="text-ink font-semibold">Рис. 1.</span> Схема термического градиента при локальном нагреве соплом фена.</span>
              <span class="hidden sm:inline-block text-stamp text-ink-faint uppercase">IPC/JEDEC</span>
            </figcaption>
          </figure>

          <!-- Minimal Specs Flow Chips -->
          <div class="py-2">
            <div class="text-stamp font-mono text-ink-faint uppercase mb-2">Опорные значения стандарта IPC/JEDEC:</div>
            <div class="flex flex-wrap items-center gap-2 font-mono text-xs">
              <span class="sketch-pill-yellow text-ink">ПОС-61: <span class="font-bold">183–190°C</span></span>
              <span class="text-ink-faint">→</span>
              <span class="sketch-pill-gray text-ink">Sn63Pb37: <span class="font-bold">183°C</span></span>
              <span class="text-ink-faint">→</span>
              <span class="sketch-pill-gray text-ink">Окно TAL: <span class="font-bold">45–75 с</span></span>
              <span class="text-ink-faint">→</span>
              <span class="sketch-pill-gray text-ink">Пик: <span class="font-bold">до 245°C</span></span>
            </div>
          </div>

          <!-- Interactive Widget Link (Editorial Lab style) -->
          <div class="my-6 p-4 sm:p-5 rounded-lg border border-paper-border bg-paper-subtle/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div class="flex-1 min-w-0 pr-4 space-y-1">
              <div class="flex items-center gap-2">
                <span class="w-6 h-6 rounded border border-paper-border bg-paper flex items-center justify-center text-ink text-xs font-mono shadow-xs">
                  <?= tp_icon('wrench', 'w-3.5 h-3.5 text-accent') ?>
                </span>
                <span class="font-mono text-stamp font-bold text-ink uppercase tracking-wider">Интерактивный верстак</span>
              </div>
              <h3 class="text-base sm:text-lg font-bold text-ink pt-0.5">Рассчитайте параметры для вашей платы</h3>
              <p class="text-xs sm:text-sm text-ink-muted leading-relaxed">Используйте селектор флюса и калькулятор расхода припоя перед началом работы.</p>
            </div>
            <a href="interactive.php#solder-consumption" class="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 min-h-[40px] bg-ink hover:bg-ink-muted text-paper rounded font-mono text-xs font-medium transition-colors shadow-sm shrink-0 whitespace-nowrap text-center">
              <span>Открыть инструменты</span>
              <?= tp_icon('arrow-right', 'w-4 h-4') ?>
            </a>
          </div>
        </section>

        <!-- Section 2: 4 Stages + Interactive Calculator -->
        <section class="scroll-mt-20 bg-paper border border-paper-border rounded-lg p-5 sm:p-6 space-y-6 shadow-sm" id="step-2">
          <div>
            <h2 class="text-xl sm:text-2xl font-bold text-ink tracking-tight">
              2. Четыре фазы кривой пайки (Интерактивный расчет)
            </h2>
            <p class="text-ink/85 mt-2">
              Технологический профиль пайки оплавлением регламентируется стандартом <code class="font-mono text-xs font-medium px-1.5 py-0.5 bg-paper-subtle border border-paper-border rounded text-ink">IPC-7530A</code> и TDS паяльных паст. Процесс сводится к четырёхступенчатому контролируемому циклу (не путать с квалификационным стресс-тестом компонентов по J-STD-020E):
            </p>
            <div class="my-3 inline-flex flex-wrap items-center gap-2.5 p-2 rounded border border-paper-border bg-paper-subtle text-xs font-mono text-ink">
              <span class="px-2 py-0.5 bg-ink text-paper rounded text-stamp font-bold tracking-wider uppercase">IPC-7530A</span>
              <span class="text-ink font-semibold">Профилирование оплавления печи</span>
              <span class="text-ink-faint text-stamp hidden sm:inline-block">|</span>
              <span class="text-ink-muted text-xs font-sans flex items-center gap-1"><?= tp_icon('alert-triangle', 'w-3.5 h-3.5 text-warning align-middle') ?>Предел нагрева: не более 2.0–2.5 °C/с (риск деламинации)</span>
            </div>
          </div>

          <!-- Hand-Drawn Sketch Graph SVG (Light & Dark Parity) -->
          <div class="sketch-frame p-4 sm:p-6 my-6 relative overflow-hidden">
            <div class="font-hand text-xl font-bold text-ink mb-3 flex items-center gap-2">
              <?= tp_icon('chart-line', 'w-5 h-5 text-accent') ?>
              Схема нагрева: T°C / Время (сек)
            </div>
            
            <div class="w-full overflow-x-auto">
              <svg viewBox="0 0 540 220" class="w-full h-auto max-w-full" fill="none" role="img" aria-label="График температурного профиля пайки: кривая температуры от времени для 4 фаз стандарта IPC/JEDEC">
                <title>График температурного профиля пайки: кривая нагрева и охлаждения по 4 фазам</title>
                <!-- Background card -->
                <rect width="540" height="220" rx="8" class="fill-paper-subtle/50 stroke-paper-border" stroke-width="1.5"/>
                
                <!-- Horizontal Guidelines -->
                <line x1="40" y1="180" x2="500" y2="180" class="stroke-paper-border-dark" stroke-width="1.5" stroke-dasharray="4 4"/>
                <line x1="40" y1="110" x2="500" y2="110" class="stroke-paper-border-dark" stroke-width="1" stroke-dasharray="3 4"/>
                <line x1="40" y1="50" x2="500" y2="50" class="stroke-paper-border-dark" stroke-width="1" stroke-dasharray="2 4"/>
                
                <!-- Sketch Curve -->
                <path d="M40 180 Q120 160 180 110 T320 50 T440 80 T500 180" class="stroke-ink" stroke-width="3" stroke-linecap="round" fill="none"/>
                
                <!-- Data Points -->
                <circle cx="180" cy="110" r="7" class="fill-[#fde047] stroke-ink" stroke-width="2"/>
                <circle cx="320" cy="50" r="7" class="fill-brand-orange stroke-ink" stroke-width="2"/>
                <circle cx="440" cy="80" r="7" class="fill-[#2dd4bf] stroke-ink" stroke-width="2"/>
                
                <!-- Hand-written Annotations -->
                <text x="110" y="96" font-family="Caveat" font-size="19" font-weight="700" class="fill-ink">Preheat (150°C)</text>
                <text x="280" y="36" font-family="Caveat" font-size="20" font-weight="700" class="fill-brand-orange">Peak (245°C) max</text>
                <text x="430" y="115" font-family="Caveat" font-size="19" font-weight="700" class="fill-ink">Cooling (6°C/s)</text>
                
                <!-- Axis Labels (≥11px) -->
                <text x="40" y="202" font-family="JetBrains Mono" font-size="11" class="fill-ink-muted">0s</text>
                <text x="170" y="202" font-family="JetBrains Mono" font-size="11" class="fill-ink-muted">90s (Soak)</text>
                <text x="305" y="202" font-family="JetBrains Mono" font-size="11" class="fill-ink-muted">210s (Reflow)</text>
                <text x="470" y="202" font-family="JetBrains Mono" font-size="11" class="fill-ink-muted">300s</text>
              </svg>
            </div>
            <div class="mt-3 text-stamp font-mono text-ink-faint flex items-center justify-between">
              <span>Рис. 2. Нормированная кривая SAC305 (Liquidus 217°C)</span>
              <span class="uppercase">IPC/JEDEC J-STD-020</span>
            </div>
          </div>

          <!-- Clean 2x2 Minimal Stage Overview -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 font-sans">
            <div class="p-4 bg-paper rounded border border-paper-border space-y-1.5">
              <div class="flex items-center justify-between text-xs font-mono pb-1">
                <span class="pill-yellow">ФАЗА 1 // PREHEAT</span>
                <span class="text-ink-muted font-mono text-xs">1–3°C/с</span>
              </div>
              <div class="font-semibold text-ink text-sm">Прогрев (Preheat)</div>
              <p class="text-xs text-ink-muted leading-snug">
                Плавный подъем до 150°C для испарения легких фракций растворителя флюса.
              </p>
            </div>
            <div class="p-4 bg-paper rounded border border-paper-border space-y-1.5">
              <div class="flex items-center justify-between text-xs font-mono pb-1">
                <span class="px-1.5 py-0.5 text-stamp uppercase font-mono text-ink-muted bg-paper-subtle border border-paper-border rounded">ФАЗА 2</span>
                <span class="text-ink-muted font-mono text-xs">150–200°C</span>
              </div>
              <div class="font-semibold text-ink text-sm">Активация (Soak)</div>
              <p class="text-xs text-ink-muted leading-snug">
                Выравнивание температурного поля чипа и платы, удаление поверхностных оксидов.
              </p>
            </div>
            <div class="p-4 bg-[#fffaf5] dark:bg-[#431407]/20 rounded border border-[#fed7aa] dark:border-[#ea580c]/30 space-y-1.5">
              <div class="flex items-center justify-between text-xs font-mono pb-1">
                <span class="pill-orange">ФАЗА 3 // REFLOW</span>
                <span class="font-semibold text-[#c2410c] dark:text-[#fdba74] font-mono text-xs">Пик 235–245°C</span>
              </div>
              <div class="font-semibold text-ink text-sm">Оплавление (Reflow)</div>
              <p class="text-xs text-ink-muted leading-snug">
                Время TAL над ликвидусом 45–75 сек. Формирование интерметаллического слоя.
              </p>
            </div>
            <div class="p-4 bg-[#f0fdfa] dark:bg-[#042f2e]/20 rounded border border-[#99f6e4] dark:border-[#14b8a6]/40 space-y-1.5">
              <div class="flex items-center justify-between text-xs font-mono pb-1">
                <span class="pill-blue"><span class="dot-blue"></span>ФАЗА 4 // COOLING</span>
                <span class="text-ink dark:text-[#5eead4] font-mono text-xs font-semibold">2–4°C/с</span>
              </div>
              <div class="font-semibold text-ink text-sm">Охлаждение (Cooling)</div>
              <p class="text-xs text-ink-muted leading-snug">
                Контролируемый спад для мелкозернистой кристаллической структуры галтели.
              </p>
            </div>
          </div>

          <!-- SIMULATOR WIDGET (Minimal editorial aesthetic from Stitch) -->
          <div class="border border-paper-border rounded-lg bg-paper-subtle/70 p-5 sm:p-6 space-y-5" id="simulator">
            <div class="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 pb-2 border-b border-paper-border">
              <div>
                <div class="text-stamp font-mono text-ink-faint uppercase tracking-wider">Инженерный калькулятор</div>
                <h3 class="text-lg font-bold text-ink">Профиль термостола и фена</h3>
              </div>
              
              <!-- Alloy pills -->
              <div class="flex flex-wrap items-center gap-2 font-mono text-xs" id="alloy-selector">
                <button class="alloy-btn px-3.5 py-2 rounded border border-ink bg-ink text-paper transition-all font-medium inline-flex items-center justify-center" data-alloy="sac305" type="button">
                  SAC305 (217–220°C)
                </button>
                <button class="alloy-btn px-3.5 py-2 rounded border border-paper-border bg-paper text-ink hover:border-ink transition-all inline-flex items-center justify-center" data-alloy="pos61" type="button">
                  ПОС-61 (183–190°C)
                </button>
                <button class="alloy-btn px-3.5 py-2 rounded border border-paper-border bg-paper text-ink hover:border-ink transition-all inline-flex items-center justify-center" data-alloy="sn42" type="button">
                  Sn42Bi58 (138°C)
                </button>
              </div>
            </div>

            <!-- Phase Switcher Tabs -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-left" id="stage-tabs">
              <button class="stage-btn p-2.5 rounded border border-paper-border bg-paper text-left transition-all hover:border-paper-border-dark" data-stage="0" type="button">
                <div class="text-stamp font-mono text-ink-faint">01 ПРОГРЕВ</div>
                <div class="text-xs font-mono text-ink mt-0.5" id="tab-temp-0">25°C → 150°C</div>
              </button>
              <button class="stage-btn p-2.5 rounded border border-paper-border bg-paper text-left transition-all hover:border-paper-border-dark" data-stage="1" type="button">
                <div class="text-stamp font-mono text-ink-faint">02 АКТИВАЦИЯ</div>
                <div class="text-xs font-mono text-ink mt-0.5" id="tab-temp-1">150°C → 190°C</div>
              </button>
              <button class="stage-btn p-2.5 rounded border border-ink bg-callout text-left transition-all shadow-sm" data-stage="2" type="button">
                <div class="text-stamp font-mono text-ink font-semibold">03 ОПЛАВЛЕНИЕ *</div>
                <div class="text-xs font-mono text-ink font-semibold mt-0.5" id="tab-temp-2">217°C → 240°C</div>
              </button>
              <button class="stage-btn p-2.5 rounded border border-paper-border bg-paper text-left transition-all hover:border-paper-border-dark" data-stage="3" type="button">
                <div class="text-stamp font-mono text-ink-faint">04 ОХЛАЖДЕНИЕ</div>
                <div class="text-xs font-mono text-ink mt-0.5" id="tab-temp-3">240°C → 100°C</div>
              </button>
            </div>

            <!-- Detailed parameters card -->
            <div class="bg-paper p-4 rounded border border-paper-border space-y-4">
              <div class="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-paper-border">
                <div class="flex items-center gap-2">
                  <span class="text-xs font-mono px-1.5 py-0.5 bg-ink text-paper rounded font-bold" id="detail-tag">ФАЗА 03</span>
                  <span class="font-semibold text-ink text-sm" id="detail-title">Оплавление (Reflow) — 217°C → 240°C</span>
                </div>
                <button class="font-mono text-xs text-ink-muted hover:text-ink underline decoration-paper-border-dark flex items-center gap-1" id="copy-stage-btn" type="button">
                  <span id="copy-btn-text">Скопировать параметры</span>
                </button>
              </div>

              <!-- Numerical parameters grid -->
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                <div class="p-2 bg-paper-subtle rounded border border-paper-border">
                  <div class="text-ink-faint text-stamp">СКОРОСТЬ / TAL</div>
                  <div class="text-ink font-semibold mt-1" id="detail-speed">TAL: 45 — 75 сек</div>
                </div>
                <div class="p-2 bg-paper-subtle rounded border border-paper-border">
                  <div class="text-ink-faint text-stamp">ДЛИТЕЛЬНОСТЬ</div>
                  <div class="text-ink font-semibold mt-1" id="detail-duration">Пик: 10 — 20 сек</div>
                </div>
                <div class="p-2 bg-paper-subtle rounded border border-paper-border">
                  <div class="text-ink-faint text-stamp">НИЖНИЙ ПОДОГРЕВ</div>
                  <div class="text-ink font-semibold mt-1" id="detail-bottom">170°C — 185°C</div>
                </div>
                <div class="p-2 bg-paper-subtle rounded border border-paper-border">
                  <div class="text-ink-faint text-stamp">СОПЛО ФЕНА</div>
                  <div class="text-ink font-semibold mt-1" id="detail-top">255°C (35 л/мин)</div>
                </div>
              </div>

              <!-- Text notes -->
              <div class="text-xs text-ink-muted space-y-2 pt-1">
                <div>
                  <strong class="text-ink font-medium">Физика процесса:</strong>
                  <span id="detail-desc">Полный переход шариков в жидкую фазу, смачивание контактных площадок и диффузионный рост интерметаллического слоя Cu6Sn5.</span>
                </div>
                <div class="p-3 rounded border border-paper-border bg-paper-subtle/50 text-xs leading-relaxed flex items-start gap-2.5 text-ink/85 mt-2">
                  <span class="font-mono text-stamp uppercase tracking-wider text-ink font-semibold shrink-0 pt-0.5">Внимание:</span>
                  <span id="detail-warning" class="text-ink/80">Превышение 248–250°C на кристалле ведет к деламинации кремниевой подложки и необратимому перегреву.</span>
                </div>
              </div>
            </div>

          </div>
        </section>

        <!-- Section 3: Alloy Temperature Windows -->
        <section class="scroll-mt-20 bg-paper border border-paper-border rounded-lg p-5 sm:p-6 space-y-5 shadow-sm" id="alloys">
          <div>
            <h2 class="text-xl sm:text-2xl font-bold text-ink tracking-tight">
              3. Температурные окна основных паяльных сплавов
            </h2>
            <p class="text-ink/85 mt-2">
              Подбирайте температурный коридор в зависимости от металлургии используемого припоя:
            </p>
          </div>

          <!-- 4 Minimalist Alloy Cards -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            
            <!-- SAC305 -->
            <div class="p-4 rounded border border-paper-border bg-paper flex flex-col justify-between space-y-3 shadow-sm">
              <div class="space-y-2">
                <div class="flex items-start justify-between">
                  <div>
                    <div class="text-stamp font-mono text-ink-faint uppercase font-semibold">Бессвинцовый стандарт</div>
                    <h3 class="font-bold text-base text-ink">SAC305</h3>
                    <div class="text-xs font-mono text-ink-muted">Sn96.5 Ag3.0 Cu0.5</div>
                  </div>
                  <div class="text-right">
                    <div class="font-mono text-lg font-bold text-ink leading-none">217°C</div>
                    <div class="text-stamp font-mono text-ink-faint uppercase mt-1">ликвидус</div>
                  </div>
                </div>
                <div class="my-2.5 py-1.5 border-y border-paper-border flex items-center justify-between text-xs font-mono">
                  <span class="text-ink-faint uppercase">Окно пайки:</span>
                  <span class="sketch-pill-gray text-ink font-bold text-xs">235°C — 245°C</span>
                </div>
                <p class="text-xs text-ink-muted leading-relaxed">
                  Заводской монтаж BGA, современные материнские платы и видеокарты. Высокая механическая прочность.
                </p>
              </div>
              <div class="pt-2 text-right">
                <button class="text-xs font-mono text-ink-muted hover:text-ink transition-colors underline decoration-paper-border cursor-pointer" onclick="if(window.TCHP_UI){window.TCHP_UI.copyToClipboard('SAC305 | Liquidus: 217C | Reflow Window: 235-245C | TAL: 45-75s', this);}else{navigator.clipboard.writeText('SAC305 | Liquidus: 217C | Reflow Window: 235-245C | TAL: 45-75s'); this.innerText='[✓ В БУФЕРЕ]';}" type="button">
                  копировать техпаспорт
                </button>
              </div>
            </div>

            <!-- Sn63Pb37 / ПОС-61 -->
            <div class="p-4 rounded border border-paper-border bg-paper flex flex-col justify-between space-y-3 shadow-sm">
              <div class="space-y-2">
                <div class="flex items-start justify-between">
                  <div>
                    <div class="text-stamp font-mono text-ink-faint uppercase font-semibold">Свинцовые сплавы</div>
                    <h3 class="font-bold text-base text-ink">Sn63Pb37 / ПОС-61</h3>
                    <div class="text-xs font-mono text-ink-muted">Sn63 (эвтектика) // ПОС-61 (ГОСТ 21931)</div>
                  </div>
                  <div class="text-right">
                    <div class="font-mono text-lg font-bold text-ink leading-none">183°C / 190°C</div>
                    <div class="text-stamp font-mono text-ink-faint uppercase mt-1">эвтектика / ликвидус</div>
                  </div>
                </div>
                <div class="my-2.5 py-1.5 border-y border-paper-border flex items-center justify-between text-xs font-mono">
                  <span class="text-ink-faint uppercase">Окно пайки:</span>
                  <span class="sketch-pill-yellow text-ink font-bold text-xs">210°C — 220°C</span>
                </div>
                <p class="text-xs text-ink-muted leading-relaxed">
                  Сервисный ремонт, реболлинг на свинец, мягкая текучесть и зеркальная галтель без микротрещин. Sn63Pb37 плавится строго при 183 °C, ПОС-61 имеет интервал 183–190 °C.
                </p>
              </div>
              <div class="pt-2 text-right">
                <button class="text-xs font-mono text-ink-muted hover:text-ink transition-colors underline decoration-paper-border cursor-pointer" onclick="if(window.TCHP_UI){window.TCHP_UI.copyToClipboard('Sn63Pb37: 183C (эвтектика) | ПОС-61: 183-190C (ГОСТ 21931) | Окно: 210-220C | TAL: 30-50s', this);}else{navigator.clipboard.writeText('Sn63Pb37: 183C (эвтектика) | ПОС-61: 183-190C (ГОСТ 21931) | Окно: 210-220C | TAL: 30-50s'); this.innerText='[✓ В БУФЕРЕ]';}" type="button">
                  копировать техпаспорт
                </button>
              </div>
            </div>

            <!-- Sn42Bi58 -->
            <div class="p-4 rounded border border-paper-border bg-paper flex flex-col justify-between space-y-3 shadow-sm">
              <div class="space-y-2">
                <div class="flex items-start justify-between">
                  <div>
                    <div class="text-stamp font-mono text-ink-faint uppercase font-semibold">Низкотемпературный</div>
                    <h3 class="font-bold text-base text-ink">Sn42Bi58</h3>
                    <div class="text-xs font-mono text-ink-muted">Sn42 Bi58 (Висмутовый)</div>
                  </div>
                  <div class="text-right">
                    <div class="font-mono text-lg font-bold text-ink leading-none">138°C</div>
                    <div class="text-stamp font-mono text-ink-faint uppercase mt-1">эвтектика</div>
                  </div>
                </div>
                <div class="my-2.5 py-1.5 border-y border-paper-border flex items-center justify-between text-xs font-mono">
                  <span class="text-ink-faint uppercase">Окно пайки:</span>
                  <span class="sketch-pill-gray text-ink font-bold text-xs">165°C — 175°C</span>
                </div>
                <p class="text-xs text-ink-muted leading-relaxed">
                  Монтаж пластиковых FPC-разъемов, OLED-шлейфов и термочувствительных датчиков MEMS без коробления.
                </p>
              </div>
              <div class="pt-2 text-right">
                <button class="text-xs font-mono text-ink-muted hover:text-ink transition-colors underline decoration-paper-border cursor-pointer" onclick="if(window.TCHP_UI){window.TCHP_UI.copyToClipboard('Sn42Bi58 | Eutectic: 138C | Reflow Window: 165-175C | TAL: 30-45s', this);}else{navigator.clipboard.writeText('Sn42Bi58 | Eutectic: 138C | Reflow Window: 165-175C | TAL: 30-45s'); this.innerText='[✓ В БУФЕРЕ]';}" type="button">
                  копировать техпаспорт
                </button>
              </div>
            </div>

            <!-- Сплав Розе -->
            <div class="p-4 rounded border border-paper-border bg-paper flex flex-col justify-between space-y-3 shadow-sm">
              <div class="space-y-2">
                <div class="flex items-start justify-between">
                  <div>
                    <div class="text-stamp font-mono text-ink-faint uppercase font-semibold">Сверхнизкоплавкий</div>
                    <h3 class="font-bold text-base text-ink">Сплав Розе</h3>
                    <div class="text-xs font-mono text-ink-muted">Bi50 Pb32 Sn18</div>
                  </div>
                  <div class="text-right">
                    <div class="font-mono text-lg font-bold text-ink leading-none">96°C</div>
                    <div class="text-stamp font-mono text-ink-faint uppercase mt-1">плавление</div>
                  </div>
                </div>
                <div class="my-2.5 py-1.5 border-y border-paper-border flex items-center justify-between text-xs font-mono">
                  <span class="text-ink-faint uppercase">Окно пайки:</span>
                  <span class="sketch-pill-gray text-ink font-bold text-xs">130°C — 140°C</span>
                </div>
                <p class="text-xs text-ink-muted leading-relaxed">
                  Исключительно для безопасного демонтажа чипов (разбавление тугоплавкого припоя). В чистом виде запрещен!
                </p>
              </div>
              <div class="pt-2 text-right">
                <button class="text-xs font-mono text-ink-muted hover:text-ink transition-colors underline decoration-paper-border cursor-pointer" onclick="if(window.TCHP_UI){window.TCHP_UI.copyToClipboard('Сплав Розе | Melting: 96C | Desoldering Window: 130-140C', this);}else{navigator.clipboard.writeText('Сплав Розе | Melting: 96C | Desoldering Window: 130-140C'); this.innerText='[✓ В БУФЕРЕ]';}" type="button">
                  копировать техпаспорт
                </button>
              </div>
            </div>

          </div>
        </section>

        <!-- Section 4: Practical details -->
        <section class="scroll-mt-20 bg-paper border border-paper-border rounded-lg p-5 sm:p-6 space-y-4 shadow-sm" id="step-4">
          <h2 class="text-xl sm:text-2xl font-bold text-ink tracking-tight">
            4. Практические нюансы: термопары, влага и деламинация
          </h2>
          <div class="space-y-4">
            
            <div class="p-4 rounded border border-paper-border bg-paper space-y-1.5">
              <div class="font-semibold text-ink text-sm">Точка замера температуры</div>
              <p class="text-sm text-ink-muted leading-relaxed">
                Закрепляйте термопару типа К каптоновым скотчем непосредственно возле корпуса микросхемы на поверхности платы. Только это дает объективную температуру в зоне пайки.
              </p>
            </div>

            <!-- Рис. 2: Схема монтажа термопары К-типа -->
            <figure class="my-6 rounded-lg border border-paper-border-dark bg-white/80 dark:bg-card p-2.5 sm:p-3 shadow-sm space-y-2.5">
              <div class="overflow-hidden rounded border border-paper-border bg-white dark:bg-paper">
                <img src="<?= $assets_base ?>/assets/schematics/thermocouple-mount.svg" alt="Схема монтажа термопары К-типа возле галтелей шариковых выводов BGA" class="w-full h-auto block object-contain">
              </div>
              <figcaption class="px-1 text-xs font-mono text-ink-muted leading-relaxed flex items-center justify-between">
                <span><span class="text-ink font-semibold">Рис. 2.</span> Схема монтажа термопары К-типа возле галтелей шариковых выводов BGA.</span>
                <span class="hidden sm:inline-block text-stamp text-ink-faint uppercase">К-тип / Каптон</span>
              </figcaption>
            </figure>

            <div class="border border-paper-border bg-callout p-4 rounded space-y-1.5">
              <div class="flex items-center gap-2">
                <span class="font-semibold text-ink text-sm">Влажность микросхем (MSL 3)</span>
                <span class="font-mono text-stamp px-1.5 py-0.5 rounded bg-paper-subtle text-ink-muted border border-paper-border font-medium">ВАЖНО</span>
              </div>
              <p class="text-sm text-ink-muted leading-relaxed">
                Если BGA-компонент лежал на воздухе дольше 72 часов, влага в полимере закипает при 230°C и распирает корпус изнутри (<strong>«эффект попкорна»</strong>). Обязательно сушите чип 12–24 часа при 100–110°C перед пайкой.
              </p>
            </div>

            <div class="p-4 rounded border border-paper-border bg-paper space-y-1.5">
              <div class="font-semibold text-ink text-sm">Критическая скорость нагрева</div>
              <p class="text-sm text-ink-muted leading-relaxed">
                Скорость нарастания температуры быстрее <strong class="text-ink">2.5–3.0°C/сек</strong> приводит к расслоению стеклотекстолита (деламинации) и обрыву внутренних переходных отверстий в плате.
              </p>
            </div>

          </div>
        </section>

        <!-- Summary Box ("Что запомнить") -->
        <div class="border border-paper-border bg-paper p-5 sm:p-6 rounded-lg space-y-3 font-sans">
          <div class="text-stamp font-mono font-bold uppercase tracking-wider text-ink flex items-center gap-1.5">
            <span>●</span> ЧТО ЗАПОМНИТЬ
          </div>
          <ul class="space-y-2 text-sm text-ink/85 leading-relaxed">
            <li class="flex items-start gap-2.5">
              <span class="text-ink-faint font-mono">—</span>
              <span>Фен без нижнего подогревателя гарантированно изгибает многослойную плату.</span>
            </li>
            <li class="flex items-start gap-2.5">
              <span class="text-ink-faint font-mono">—</span>
              <span>Всегда фиксируйте термопару на плате — температура на выходе сопла фена завышена на 80–100°C.</span>
            </li>
            <li class="flex items-start gap-2.5">
              <span class="text-ink-faint font-mono">—</span>
              <span>Оптимальное время над ликвидусом (TAL) для SAC305 составляет строго <strong>45–75 секунд</strong>.</span>
            </li>
            <li class="flex items-start gap-2.5">
              <span class="text-ink-faint font-mono">—</span>
              <span>Бессвинцовая пайка требует пика 235–245°C; нагрев свыше 250°C разрушает кристалл и текстолит.</span>
            </li>
            <li class="flex items-start gap-2.5">
              <span class="text-ink-faint font-mono">—</span>
              <span>Влажные BGA-микросхемы перед монтажом обязательно требуют просушки 12 часов при 100°C.</span>
            </li>
          </ul>
        </div>



        <?php if (false): /* [РЕКЛАМА / МОНЕТИЗАЦИЯ ОТКЛЮЧЕНА]: In-Article Native RSYA Ad Container */ ?>
        <!-- In-Article Native RSYA Ad Container -->
        <div class="my-8 p-4 rounded border border-dashed border-paper-border bg-paper-subtle/40 text-center">
          <div class="text-stamp font-mono text-ink-faint uppercase mb-1">РЕКЛАМА / ПАРТНЕРСКИЙ БЛОК ЯНДЕКСА</div>
          <div id="yandex_rtb_in_article" class="min-h-[100px] flex items-center justify-center text-xs font-mono text-ink-muted border border-paper-border rounded bg-paper">
            [Контейнер РСЯ In-Article · Адаптивный блок]
          </div>
        </div>
        <?php endif; ?>

        <!-- Section: FAQ Accordion -->
        <section class="scroll-mt-20 space-y-4" id="faq">
          <h2 class="text-xl sm:text-2xl font-bold text-ink tracking-tight">
            Частые вопросы
          </h2>
          <div class="border-t border-paper-border divide-y divide-paper-border">
            <?php 
            $faq_idx = 0;
            foreach ($faq_items as $question => $answer): 
                $faq_idx++;
                $faq_id = 'faq-item-' . $faq_idx;
            ?>
              <div class="py-3.5">
                <button class="faq-toggle w-full text-left flex items-start justify-between gap-4 font-medium text-ink hover:text-ink-muted transition-colors text-sm sm:text-base" type="button" aria-expanded="false" aria-controls="<?= $faq_id ?>">
                  <span><?= e($question) ?></span>
                  <span class="font-mono text-ink-faint text-xs mt-0.5 plus-icon" aria-hidden="true">+</span>
                </button>
                <div id="<?= $faq_id ?>" class="faq-content hidden pt-2 text-sm text-ink-muted leading-relaxed">
                  <?= e($answer) ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </section>

        <?php if (false): /* [РЕКЛАМА / МОНЕТИЗАЦИЯ ОТКЛЮЧЕНА]: Affiliate Product Showcase (Yandex Market / Chip & Dip) */ ?>
        <!-- Affiliate Product Showcase (Yandex Market / Chip & Dip) -->
        <section class="my-8 p-5 sm:p-6 rounded-lg border border-paper-border bg-card space-y-4">
          <div class="flex items-center justify-between border-b border-paper-border pb-3">
            <div class="flex items-center gap-2">
              <?= tp_icon('wrench', 'w-4 h-4 text-accent') ?>
              <h3 class="font-bold text-xs sm:text-sm text-ink uppercase font-mono">Проверенное оборудование и химия к статье</h3>
            </div>
            <span class="text-stamp font-mono text-ink-faint">МАРКЕТ / ЧИПДИП</span>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 font-sans">
            <a href="https://market.yandex.ru" target="_blank" rel="sponsored nofollow noopener" class="p-3 border border-paper-border rounded bg-paper hover:border-paper-border-dark transition-all block group">
              <div class="text-stamp font-mono text-ink-faint uppercase">Термовоздушная станция</div>
              <div class="font-bold text-xs text-ink group-hover:text-accent mt-0.5">Quick 861DW (1000W)</div>
              <div class="text-stamp text-ink-muted mt-1 leading-snug">Турбированный термофен для BGA чипов</div>
              <div class="mt-3 pt-2 border-t border-paper-border flex items-center justify-between text-xs font-mono">
                <span class="font-bold text-ink">от 24 500 ₽</span>
                <span class="text-accent underline text-stamp">Маркет →</span>
              </div>
            </a>
            <a href="https://market.yandex.ru" target="_blank" rel="sponsored nofollow noopener" class="p-3 border border-paper-border rounded bg-paper hover:border-paper-border-dark transition-all block group">
              <div class="text-stamp font-mono text-ink-faint uppercase">Флюс-гель No-Clean</div>
              <div class="font-bold text-xs text-ink group-hover:text-accent mt-0.5">Cyberflux RMA-218</div>
              <div class="text-stamp text-ink-muted mt-1 leading-snug">Безотмывочный гель для бессвинца</div>
              <div class="mt-3 pt-2 border-t border-paper-border flex items-center justify-between text-xs font-mono">
                <span class="font-bold text-ink">от 950 ₽</span>
                <span class="text-accent underline text-stamp">Маркет →</span>
              </div>
            </a>
            <a href="https://market.yandex.ru" target="_blank" rel="sponsored nofollow noopener" class="p-3 border border-paper-border rounded bg-paper hover:border-paper-border-dark transition-all block group">
              <div class="text-stamp font-mono text-ink-faint uppercase">Припой SAC305</div>
              <div class="font-bold text-xs text-ink group-hover:text-accent mt-0.5">BGA Balls 0.45mm</div>
              <div class="text-stamp text-ink-muted mt-1 leading-snug">Прецизионные шарики Sn96.5Ag3Cu0.5</div>
              <div class="mt-3 pt-2 border-t border-paper-border flex items-center justify-between text-xs font-mono">
                <span class="font-bold text-ink">от 1 200 ₽</span>
                <span class="text-accent underline text-stamp">Маркет →</span>
              </div>
            </a>
          </div>

          <!-- 347-ФЗ Маркировка рекламы -->
          <div class="pt-3 border-t border-paper-border flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-stamp font-mono text-ink-faint">
            <span>Реклама · erid и данные о рекламодателях доступны по ссылкам перехода</span>
            <span>ООО «Яндекс», ИНН 7736207543 / ООО «Интернет Решения», ИНН 7704217370</span>
          </div>
        </section>
        <?php endif; ?>

        <?php if (false): /* [РЕКЛАМА / МОНЕТИЗАЦИЯ ОТКЛЮЧЕНА]: B2B / Lead-Gen Rework Module */ ?>
        <!-- B2B / Lead-Gen Rework Module -->
        <div class="my-8 p-5 rounded-lg border-2 border-paper-border-dark bg-paper-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-4 sketch-border">
          <div class="space-y-1">
            <div class="flex items-center gap-2 flex-wrap">
              <span class="sketch-pill-yellow text-ink text-stamp font-mono font-bold">СЕРВИСНЫЙ ЦЕНТР ТЧП</span>
              <span class="text-xs font-bold text-ink">Нужен сложный BGA-ремонт платы?</span>
            </div>
            <p class="text-xs text-ink-muted max-w-lg leading-relaxed">
              Диагностика и замена BGA-чипов, видеокарт и процессоров на оборудовании с термопрофилированием по IPC-A-610.
            </p>
          </div>
          <a href="interactive.php" class="px-4 py-2 bg-ink text-paper text-xs font-mono font-semibold rounded hover:opacity-90 transition-opacity shrink-0 text-center border border-paper-border-dark shadow-sm">
            Заказать диагностику →
          </a>
        </div>
        <?php endif; ?>

        <!-- Self-Check Block (Проверьте себя) -->
        <section class="my-8 p-6 rounded-lg border border-accent bg-paper-subtle space-y-4">
          <div class="flex items-center gap-2">
            <?= tp_icon('check', 'w-5 h-5 text-accent') ?>
            <h2 class="text-xl font-bold text-ink">Проверьте себя</h2>
          </div>
          <p class="text-sm text-ink-muted">Готовы применить знания на практике? Воспользуйтесь нашими инструментами для расчета параметров.</p>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <a href="interactive.php#temp" class="block p-4 rounded bg-paper border border-paper-border hover:border-accent transition-colors">
              <div class="font-bold text-ink text-sm">Термокалькулятор</div>
              <div class="text-xs text-ink-muted mt-1">Рассчитать режим жала</div>
            </a>
            <a href="interactive.php#defect" class="block p-4 rounded bg-paper border border-paper-border hover:border-accent transition-colors">
              <div class="font-bold text-ink text-sm">Дерево дефектов</div>
              <div class="text-xs text-ink-muted mt-1">Диагностика брака пайки</div>
            </a>
          </div>
        </section>
        <?php else: ?>
        <!-- Engineering Article Draft / In-Development Workbench View -->
        <div class="border border-warning-border bg-warning-bg/30 p-5 rounded-lg space-y-3">
          <div class="flex items-center justify-between flex-wrap gap-2">
            <span class="text-stamp font-mono font-bold uppercase tracking-wider text-warning flex items-center gap-1.5">
              <?= tp_icon('filter', 'w-4 h-4') ?>
              Инженерный регламент ТЧП // Статус: Лабораторные замеры
            </span>
            <span class="text-xs font-mono px-2 py-0.5 rounded bg-warning-bg text-ink border border-warning-border font-bold">
              В разработке
            </span>
          </div>
          <p class="text-sm text-ink/85 leading-relaxed">
            Данный технический регламент проходит этап практической верификации параметров на термовоздушных и контактных станциях лаборатории. Ниже приведены базовые параметры технологического процесса, допуски и ссылки на готовые инструменты.
          </p>
        </div>

        <!-- Technical Parameters Card -->
        <div class="bg-paper border border-paper-border rounded-lg p-5 sm:p-6 space-y-4 shadow-sm">
          <div class="flex items-center justify-between pb-3 border-b border-paper-border">
            <h2 class="text-lg font-bold text-ink font-mono uppercase tracking-tight">Параметры и спецификация</h2>
            <span class="text-xs font-mono text-ink-muted">IPC-A-610 / ГОСТ</span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div class="p-3 rounded bg-paper-subtle border border-paper-border space-y-1">
              <div class="text-ink-faint uppercase text-stamp">Категория монтажа</div>
              <div class="text-ink font-bold text-sm"><?= e($article['tag'] ?? 'РЭА') ?></div>
            </div>
            <div class="p-3 rounded bg-paper-subtle border border-paper-border space-y-1">
              <div class="text-ink-faint uppercase text-stamp">Уровень сложности</div>
              <div class="text-ink font-bold text-sm"><?= e($article['difficulty'] ?? 'Инженер') ?></div>
            </div>
            <div class="p-3 rounded bg-paper-subtle border border-paper-border space-y-1">
              <div class="text-ink-faint uppercase text-stamp">Расчетное время изучения</div>
              <div class="text-ink font-bold text-sm">~<?= e($article['read_min'] ?? 7) ?> минут</div>
            </div>
            <div class="p-3 rounded bg-paper-subtle border border-paper-border space-y-1">
              <div class="text-ink-faint uppercase text-stamp">Необходимый инструмент</div>
              <div class="text-ink font-semibold"><?= e(implode(', ', $article['required_tools'] ?? ['Паяльная станция', 'Термопара'])) ?></div>
            </div>
          </div>

          <div class="pt-2 text-sm text-ink-muted leading-relaxed font-serif">
            <p>
              Полная версия статьи будет включать тепловизионные снимки распределения температурных полей, пошаговый разбор типичных дефектов, графики температурных профилей и перечень сертифицированных расходных материалов (флюсы, припои, оплётки).
            </p>
          </div>
        </div>

        <!-- Available Tools Callout -->
        <div class="bg-card border border-paper-border rounded-lg p-5 space-y-3 shadow-sm">
          <div class="font-mono text-xs font-bold uppercase text-ink flex items-center gap-1.5">
            <?= tp_icon('sliders', 'w-4 h-4 text-accent') ?>
            <span>Инструменты для этой задачи</span>
          </div>
          <p class="text-xs sm:text-sm text-ink-muted leading-relaxed">
            Пока готовится публикация регламента, вы можете рассчитать точные температурные режимы, время выдержки и теплоемкость в нашем интерактивном верстаке:
          </p>
          <div class="flex flex-wrap gap-2 pt-1 font-mono text-xs">
            <a href="interactive.php#temp" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-ink text-paper font-semibold hover:bg-ink-muted transition-colors">
              <span>Калькулятор t°C пайки →</span>
            </a>
            <a href="article.php?slug=temperaturnye-profili" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded border border-paper-border bg-paper text-ink hover:border-paper-border-dark transition-colors">
              <span>Базовый регламент BGA →</span>
            </a>
          </div>
        </div>
        <?php endif; ?>

        <!-- Interactive Tools Box (tochkicamp style bottom CTA) -->
        <div class="border border-paper-border rounded-lg bg-paper p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div class="space-y-0.5">
            <div class="font-semibold text-sm text-ink">Инженерный справочник и калькуляторы ТЧП</div>
            <p class="text-xs text-ink-muted">Таблицы термопрофилей, допуски IPC-A-610 и подбор флюсов в интерактивном верстаке.</p>
          </div>
          <a class="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 border border-ink bg-ink text-paper text-xs font-mono font-medium rounded hover:bg-ink-muted transition-colors shrink-0 shadow-sm" href="interactive.php">
            <span>Открыть калькуляторы →</span>
          </a>
        </div>

        <!-- Related Reading -->
        <div class="pt-4 space-y-3">
          <div class="text-stamp font-mono text-ink-faint uppercase">Другие материалы:</div>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <?php foreach ($related_articles as $rel): ?>
              <a class="p-3 border border-paper-border rounded bg-paper hover:border-paper-border-dark transition-colors block" href="article.php?slug=<?= e($rel['slug']) ?>">
                <div class="text-stamp font-mono text-ink-faint uppercase"><?= e($rel['category'] ?? 'Материал') ?></div>
                <div class="font-medium text-ink mt-1"><?= e($rel['title']) ?></div>
              </a>
            <?php endforeach; ?>
          </div>
        </div>

      </div>

      <!-- Sticky Floating Table of Contents Sidebar (Desktop) -->
      <aside class="hidden lg:block lg:col-span-4 sticky top-20 space-y-6">
        
        <?php if (!empty($lesson)): ?>
        <!-- Lesson Passport & Checklist Progress -->
        <div class="border border-paper-border bg-paper p-4 rounded-lg space-y-3 shadow-sm">
          <div class="flex items-center justify-between text-stamp font-mono text-ink-faint uppercase pb-2 border-b border-paper-border">
            <span>ПАСПОРТ УРОКА</span>
            <span class="text-accent font-bold">2–3 МИН</span>
          </div>
          <div class="space-y-2 text-xs font-mono">
            <div class="flex items-center justify-between py-1 border-b border-paper-border/60">
              <span class="text-ink-muted">Статус:</span>
              <span class="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span> Регламент готов
              </span>
            </div>
            <div class="flex items-center justify-between py-1 border-b border-paper-border/60">
              <span class="text-ink-muted">Категория:</span>
              <span class="text-ink font-bold"><?= e($lesson['tag']) ?></span>
            </div>
            <div class="flex items-center justify-between py-1 border-b border-paper-border/60">
              <span class="text-ink-muted">Сложность:</span>
              <span class="text-ink"><?= e($lesson['difficulty']) ?></span>
            </div>
            <div class="flex items-center justify-between py-1 border-b border-paper-border/60">
              <span class="text-ink-muted">Чтение:</span>
              <span class="text-ink">~<?= e($lesson['read_min']) ?> мин</span>
            </div>
            <div class="flex items-center justify-between pt-1">
              <span class="text-ink-muted">Чек-лист:</span>
              <span id="sidebar-check-status" class="font-bold text-accent">0/<?= count($lesson['checklist']) ?> выполнено</span>
            </div>
          </div>
        </div>

        <!-- 10 Micro-lessons Series Navigation -->
        <div class="border border-paper-border bg-paper p-4 rounded-lg space-y-3 shadow-sm">
          <div class="flex items-center justify-between text-stamp font-mono text-ink-faint uppercase pb-2 border-b border-paper-border">
            <span>ВСЕ 10 МИКРОУРОКОВ</span>
            <span>СЕРИЯ ТЧП</span>
          </div>
          <nav class="space-y-1 text-xs font-mono max-h-[360px] overflow-y-auto pr-1">
            <?php foreach (get_all_lessons() as $idx => $l): ?>
              <?php $is_curr = ($l['slug'] === $lesson['slug']); ?>
              <a href="article.php?slug=<?= e($l['slug']) ?>" 
                 class="block px-2.5 py-2 rounded transition-all <?= $is_curr ? 'bg-ink text-paper font-bold shadow-xs' : 'text-ink-muted hover:text-ink hover:bg-paper-subtle' ?>">
                <div class="flex items-center justify-between gap-2">
                  <span class="truncate"><?= ($idx + 1) ?>. <?= e($l['title']) ?></span>
                  <span class="text-stamp <?= $is_curr ? 'text-paper/70' : 'text-ink-faint' ?> shrink-0"><?= $l['read_min'] ?>м</span>
                </div>
              </a>
            <?php endforeach; ?>
          </nav>
        </div>

        <?php elseif ($slug === 'temperaturnye-profili'): ?>

        <!-- Table of Contents -->
        <div class="border border-paper-border bg-paper p-4 rounded-lg space-y-3">
          <div class="flex items-center justify-between text-stamp font-mono text-ink-faint uppercase pb-2 border-b border-paper-border">
            <span>СОДЕРЖАНИЕ</span>
            <span>4 раздела</span>
          </div>
          <nav class="space-y-1 text-xs font-mono" id="toc-nav">
            <a class="toc-link block px-2 py-1 rounded text-ink font-semibold hover:bg-paper-subtle transition-colors" href="#step-1">
              1. Теплоемкость и датчики
            </a>
            <a class="toc-link block px-2 py-1 rounded text-ink-muted hover:text-ink hover:bg-paper-subtle transition-colors" href="#step-2">
              2. Четыре фазы кривой
            </a>
            <a class="toc-link block px-2 py-1 rounded text-ink-muted hover:text-ink hover:bg-paper-subtle transition-colors" href="#alloys">
              3. Температурные окна
            </a>
            <a class="toc-link block px-2 py-1 rounded text-ink-muted hover:text-ink hover:bg-paper-subtle transition-colors" href="#step-4">
              4. Практика и защита от брака
            </a>
            <a class="toc-link block px-2 py-1 rounded text-ink-muted hover:text-ink hover:bg-paper-subtle transition-colors" href="#faq">
              Частые вопросы
            </a>
          </nav>
        </div>
        <?php else: ?>
        <!-- Technical Summary Sidebar Card -->
        <div class="border border-paper-border bg-paper p-4 rounded-lg space-y-3">
          <div class="flex items-center justify-between text-stamp font-mono text-ink-faint uppercase pb-2 border-b border-paper-border">
            <span>ПАСПОРТ МАТЕРИАЛА</span>
            <span>ТЧП-LAB</span>
          </div>
          <div class="space-y-2 text-xs font-mono">
            <div class="flex items-center justify-between py-1 border-b border-paper-border/60">
              <span class="text-ink-muted">Статус:</span>
              <span class="font-semibold text-amber-700 dark:text-amber-400">В разработке</span>
            </div>
            <div class="flex items-center justify-between py-1 border-b border-paper-border/60">
              <span class="text-ink-muted">Категория:</span>
              <span class="text-ink"><?= e($article['tag'] ?? 'РЭА') ?></span>
            </div>
            <div class="flex items-center justify-between py-1 border-b border-paper-border/60">
              <span class="text-ink-muted">Сложность:</span>
              <span class="text-ink"><?= e($article['difficulty'] ?? 'Инженер') ?></span>
            </div>
            <div class="flex items-center justify-between py-1">
              <span class="text-ink-muted">Чтение:</span>
              <span class="text-ink">~<?= e($article['read_min'] ?? 7) ?> мин</span>
            </div>
          </div>
        </div>
        <?php endif; ?>

        <?php if (false): /* [РЕКЛАМА / МОНЕТИЗАЦИЯ ОТКЛЮЧЕНА]: Sticky Sidebar РСЯ Slot */ ?>
        <!-- Sticky Sidebar РСЯ Slot -->
        <div class="border border-dashed border-paper-border bg-paper p-4 rounded-lg text-center space-y-2">
          <div class="text-stamp font-mono text-ink-faint uppercase">РЕКЛАМА РСЯ</div>
          <div id="yandex_rtb_sidebar" class="min-h-[220px] flex items-center justify-center text-xs font-mono text-ink-muted bg-paper-subtle rounded border border-paper-border">
            [РСЯ Сайдбар · 300x250]
          </div>
        </div>
        <?php endif; ?>

        <!-- Interactive Workbench Bridge -->
        <!-- Quick Lab Drawer Trigger Card (Framework & Kowalski) -->
        <div class="playdate-card cad-corner-marks p-4 rounded space-y-3">
          <div class="flex items-center justify-between font-mono text-xs pb-1.5 border-b border-paper-border">
            <span class="text-accent text-stamp uppercase font-bold flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-cyan inline-block"></span>
              ЭКСПРЕСС-ВЕРСТАК
            </span>
            <span class="text-ink-faint">MOD.04 // DRAWER</span>
          </div>
          <div class="space-y-1">
            <div class="text-xs font-bold text-ink font-mono uppercase tracking-wide">
              Экспресс-калькулятор
            </div>
            <p class="text-xs text-ink-muted leading-relaxed">
              Мгновенный расчет сплавов, допустимого тока провода и проверка классов флюса прямо на странице статьи.
            </p>
          </div>
          <button type="button" onclick="if(window.openLabDrawer)window.openLabDrawer();" aria-haspopup="dialog" aria-expanded="false" aria-controls="lab-drawer-backdrop" aria-label="Открыть выдвижной верстак" class="btn btn-primary w-full text-xs font-mono py-2 flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:translate-y-0.5">
            <?= tp_icon('sliders', 'w-3.5 h-3.5') ?>
            <span>Выдвинуть верстак ↗</span>
          </button>
        </div>

      </aside>

    </div>

  </div>
</main>

<!-- Editorial Minimal Footer -->
<?php require_once __DIR__ . '/includes/footer-editorial.php'; ?>

<!-- Interactive Simulator & UX Scripts (Stitch code) -->
<script src="assets/js/ui-helpers.js"></script>
<script>
(function() {
  const alloyData = {
    sac305: {
      name: 'SAC305 (Sn96.5 Ag3.0 Cu0.5)',
      stages: [
        {
          tabTemp: '25°C → 150°C',
          tag: 'ФАЗА 01',
          title: 'Прогрев (Preheat) — 25°C → 150°C',
          speed: '1.0 — 2.5°C/сек',
          duration: '60 — 90 сек',
          bottom: '120°C — 140°C',
          top: '180°C (25 л/мин)',
          desc: 'Плавный подогрев многослойной платы для исключения термического удара и коробления текстолита.',
          warning: 'Скорость свыше 3.0°C/с приводит к микротрещинам в керамических конденсаторах MLCC.'
        },
        {
          tabTemp: '150°C → 190°C',
          tag: 'ФАЗА 02',
          title: 'Активация (Soak) — 150°C → 190°C',
          speed: '0.5 — 1.0°C/сек',
          duration: '60 — 120 сек',
          bottom: '150°C — 160°C',
          top: '210°C (30 л/мин)',
          desc: 'Выравнивание температурного поля под чипом и по краям платы. Химическое травление оксидов меди флюсом.',
          warning: 'Слишком долгий soak (>120с) полностью выжигает активность флюса до фазы оплавления.'
        },
        {
          tabTemp: '217°C → 240°C',
          tag: 'ФАЗА 03',
          title: 'Оплавление (Reflow) — 217°C → 240°C',
          speed: 'TAL: 45 — 75 сек',
          duration: 'Пик: 10 — 20 сек',
          bottom: '170°C — 185°C',
          top: '255°C (35 л/мин)',
          desc: 'Полный переход шариков в жидкую фазу, смачивание контактных площадок и диффузионный рост интерметаллического слоя Cu6Sn5.',
          warning: 'Превышение 248–250°C на кристалле ведет к деламинации кремниевой подложки и необратимому перегреву.'
        },
        {
          tabTemp: '240°C → 100°C',
          tag: 'ФАЗА 04',
          title: 'Охлаждение (Cooling) — 240°C → 100°C',
          speed: '2.0 — 4.0°C/сек',
          duration: '40 — 60 сек',
          bottom: 'Отключен',
          top: 'Остывание (обдув)',
          desc: 'Быстрая контролируемая кристаллизация припоя, обеспечивающая мелкодисперсную пластичную структуру галтелей.',
          warning: 'Охлаждение медленнее 1°C/с образует хрупкие игольчатые кристаллы интерметаллида.'
        }
      ]
    },
    pos61: {
      name: 'ПОС-61 (ГОСТ 21930-76, 59–61% Sn)',
      stages: [
        {
          tabTemp: '25°C → 130°C',
          tag: 'ФАЗА 01',
          title: 'Прогрев (Preheat) — 25°C → 130°C',
          speed: '1.0 — 2.0°C/сек',
          duration: '60 — 80 сек',
          bottom: '110°C — 120°C',
          top: '160°C (25 л/мин)',
          desc: 'Плавный подъем температуры для безопасного старта испарения растворителей флюса.',
          warning: 'Избегайте локального нагрева: нижний подогрев обязателен для свинца на платах толще 1.2 мм.'
        },
        {
          tabTemp: '130°C → 165°C',
          tag: 'ФАЗА 02',
          title: 'Активация (Soak) — 130°C → 165°C',
          speed: '0.5 — 1.0°C/сек',
          duration: '50 — 90 сек',
          bottom: '135°C — 145°C',
          top: '185°C (30 л/мин)',
          desc: 'Равномерный прогрев шариков BGA и активация смоляных кислот флюса.',
          warning: 'Не задерживайте температуру выше 170°C, чтобы не истощить флюс.'
        },
        {
          tabTemp: '183°C → 215°C',
          tag: 'ФАЗА 03',
          title: 'Оплавление (Reflow) — 183°C (солидус) / 190°C (ликвидус) → 215°C',
          speed: 'TAL (>190°C): 35 — 60 сек',
          duration: 'Пик: 10 — 15 сек',
          bottom: '150°C — 160°C',
          top: '225°C (30 л/мин)',
          desc: 'Переход через температурный интервал кристаллизации (солидус 183 °C, ликвидус 190 °C). Зеркальная блестящая галтель при температуре соединения выше 205 °C.',
          warning: 'Нагрев свыше 225°C избыточен. В интервале 183–190 °C недопустимы механические колебания платы.'
        },
        {
          tabTemp: '215°C → 90°C',
          tag: 'ФАЗА 04',
          title: 'Охлаждение (Cooling) — 215°C → 90°C',
          speed: '2.0 — 3.5°C/сек',
          duration: '35 — 50 сек',
          bottom: 'Отключен',
          top: 'Остывание (обдув)',
          desc: 'Формирование блестящей гладкой структуры паяного соединения без раковин.',
          warning: 'Не допускайте резкого удара холодом из компрессора (термошок).'
        }
      ]
    },
    sn42: {
      name: 'Sn42Bi58 (Низкотемпературный)',
      stages: [
        {
          tabTemp: '25°C → 100°C',
          tag: 'ФАЗА 01',
          title: 'Прогрев (Preheat) — 25°C → 100°C',
          speed: '1.0°C/сек',
          duration: '50 — 70 сек',
          bottom: '80°C — 90°C',
          top: '130°C (20 л/мин)',
          desc: 'Деликатный нагрев термопластичных шлейфов и тонких подложек.',
          warning: 'Осторожно с давлением воздуха из сопла: пластик разъемов размягчается.'
        },
        {
          tabTemp: '100°C → 125°C',
          tag: 'ФАЗА 02',
          title: 'Активация (Soak) — 100°C → 125°C',
          speed: '0.4 — 0.8°C/сек',
          duration: '40 — 60 сек',
          bottom: '100°C — 110°C',
          top: '145°C (25 л/мин)',
          desc: 'Стабилизация температуры перед мгновенной эвтектикой висмута.',
          warning: 'Не применяйте высокоактивные спирто-канифольные флюсы с высокой температурой активации.'
        },
        {
          tabTemp: '138°C → 165°C',
          tag: 'ФАЗА 03',
          title: 'Оплавление (Reflow) — 138°C → 165°C',
          speed: 'TAL: 30 — 45 сек',
          duration: 'Пик: 8 — 12 сек',
          bottom: '120°C — 130°C',
          top: '175°C (25 л/мин)',
          desc: 'Низкотемпературная посадка чувствительных кремниевых датчиков и светодиодов.',
          warning: 'Висмут хрупок на изгиб: не используйте для плат с механической нагрузкой.'
        },
        {
          tabTemp: '165°C → 80°C',
          tag: 'ФАЗА 04',
          title: 'Охлаждение (Cooling) — 165°C → 80°C',
          speed: '1.5 — 2.5°C/сек',
          duration: '30 — 40 сек',
          bottom: 'Отключен',
          top: 'Остывание (обдув)',
          desc: 'Аккуратный естественный спад температуры без температурного шока полимеров.',
          warning: 'Не подвергайте плату механическим вибрациям до полного затвердевания (130°C).'
        }
      ]
    }
  };

  let currentAlloy = 'sac305';
  let currentStage = 2; // Reflow active

  function renderSimulator() {
    if (!document.getElementById('simulator') || !document.getElementById('detail-tag')) return;
    const alloy = alloyData[currentAlloy];

    // Update tab temps
    for (let i = 0; i < 4; i++) {
      const tabElem = document.getElementById('tab-temp-' + i);
      if (tabElem) tabElem.textContent = alloy.stages[i].tabTemp;
    }

    // Style stage tabs
    const stageButtons = document.querySelectorAll('.stage-btn');
    stageButtons.forEach((btn, idx) => {
      const titleDiv = btn.querySelector('div:first-child');
      const tempDiv = btn.querySelector('div:last-child');
      if (idx === currentStage) {
        btn.className = 'stage-btn p-2.5 rounded border border-ink bg-callout text-left transition-all shadow-sm';
        if (titleDiv) titleDiv.className = 'text-stamp font-mono text-ink font-semibold';
        if (tempDiv) tempDiv.className = 'text-xs font-mono text-ink font-semibold mt-0.5';
      } else {
        btn.className = 'stage-btn p-2.5 rounded border border-paper-border bg-paper text-left transition-all hover:border-paper-border-dark';
        if (titleDiv) titleDiv.className = 'text-stamp font-mono text-ink-faint';
        if (tempDiv) tempDiv.className = 'text-xs font-mono text-ink mt-0.5';
      }
    });

    // Update active stage details
    const st = alloy.stages[currentStage];
    document.getElementById('detail-tag').textContent = st.tag;
    document.getElementById('detail-title').textContent = st.title;
    document.getElementById('detail-speed').textContent = st.speed;
    document.getElementById('detail-duration').textContent = st.duration;
    document.getElementById('detail-bottom').textContent = st.bottom;
    document.getElementById('detail-top').textContent = st.top;
    document.getElementById('detail-desc').textContent = st.desc;
    document.getElementById('detail-warning').textContent = st.warning;
  }

  // Alloy clicks
  const alloyButtons = document.querySelectorAll('.alloy-btn');
  alloyButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      currentAlloy = btn.getAttribute('data-alloy');
      alloyButtons.forEach(b => {
        b.className = 'alloy-btn px-2.5 py-1 rounded border border-paper-border bg-paper text-ink hover:border-ink transition-all';
      });
      btn.className = 'alloy-btn px-2.5 py-1 rounded border border-ink bg-ink text-paper transition-all font-medium';
      renderSimulator();
    });
  });

  // Stage tab clicks
  const stageButtons = document.querySelectorAll('.stage-btn');
  stageButtons.forEach((btn, idx) => {
    btn.addEventListener('click', () => {
      currentStage = idx;
      renderSimulator();
    });
  });

  // Copy stage parameters
  const copyBtn = document.getElementById('copy-stage-btn');
  const copyBtnText = document.getElementById('copy-btn-text');
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const st = alloyData[currentAlloy].stages[currentStage];
      const text = `${alloyData[currentAlloy].name} | ${st.title} | Скорость/TAL: ${st.speed} | Стол: ${st.bottom} | Фен: ${st.top}`;
      if (window.TCHP_UI && window.TCHP_UI.copyToClipboard) {
        window.TCHP_UI.copyToClipboard(text, copyBtnText, 'Скопировано в буфер!');
      } else {
        navigator.clipboard.writeText(text).then(() => {
          copyBtnText.textContent = 'Скопировано в буфер!';
          setTimeout(() => {
            copyBtnText.textContent = 'Скопировать параметры';
          }, 2000);
        });
      }
    });
  }

  // FAQ accordion with accessible state
  const faqToggles = document.querySelectorAll('.faq-toggle');
  faqToggles.forEach(btn => {
    btn.addEventListener('click', () => {
      const content = btn.nextElementSibling;
      const plus = btn.querySelector('.plus-icon');
      const isClosed = content.classList.contains('hidden');
      
      if (isClosed) {
        content.classList.remove('hidden');
        btn.setAttribute('aria-expanded', 'true');
        if (plus) plus.textContent = '—';
      } else {
        content.classList.add('hidden');
        btn.setAttribute('aria-expanded', 'false');
        if (plus) plus.textContent = '+';
      }
    });
  });

  // Highlight active TOC link on scroll
  const sections = document.querySelectorAll('section[id]');
  const tocLinks = document.querySelectorAll('.toc-link');

  window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(sec => {
      const top = sec.offsetTop - 110;
      if (window.pageYOffset >= top) {
        current = sec.getAttribute('id');
      }
    });

    tocLinks.forEach(link => {
      const href = link.getAttribute('href').replace('#', '');
      if (href === current) {
        link.classList.add('text-ink', 'font-semibold', 'bg-paper-subtle');
        link.classList.remove('text-ink-muted');
      } else {
        link.classList.remove('text-ink', 'font-semibold', 'bg-paper-subtle');
        link.classList.add('text-ink-muted');
      }
    });
  });

  // Reading Progress Bar listener
  window.addEventListener('scroll', () => {
    const h = document.documentElement, b = document.body;
    const st = 'scrollTop', sh = 'scrollHeight';
    const percent = ((h[st]||b[st]) / ((h[sh]||b[sh]) - h.clientHeight)) * 100;
    const bar = document.getElementById('reading-progress-bar');
    if (bar) bar.style.width = Math.min(100, Math.max(0, percent)) + '%';
  }, { passive: true });

  // Initial run
  renderSimulator();

  // Theme Toggle listener
  const toggleBtn = document.getElementById('theme-toggle');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const isDark = document.documentElement.classList.toggle('dark');
      localStorage.setItem('tp_theme', isDark ? 'dark' : 'light');
    });
  }
})();
</script>

  <!-- Tactile Lab Drawer (Teenage Engineering & Emil Kowalski pattern) -->
  <?php require_once __DIR__ . '/includes/lab-drawer.php'; ?>

  <!-- Mobile Sticky Quick Bar (44px WCAG Touch Targets) -->
  <?php require_once __DIR__ . '/includes/mobile-bar.php'; ?>

  <!-- Global Engineering Search Modal (Ctrl+K) -->
  <?php require_once __DIR__ . '/includes/search-modal.php'; ?>

</body>
</html>
