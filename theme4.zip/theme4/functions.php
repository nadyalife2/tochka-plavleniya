<?php
/**
 * Theme Setup & Functions for ТОЧКА ПЛАВЛЕНИЯ
 *
 * @package ТОЧКА ПЛАВЛЕНИЯ
 * @version 4.0.0
 */

defined('ABSPATH') || exit;

// 1. Load helper functions if available
if (file_exists(__DIR__ . '/includes/functions.php')) {
    require_once __DIR__ . '/includes/functions.php';
}

// 2. Theme Setup
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(800, 450, true);
    add_theme_support('html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
        'navigation-widgets'
    ]);
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    add_theme_support('editor-styles');
    // Стили темы для редактора блоков: без tokens/build/base паттерны и
    // типографика статьи выглядели в редакторе «бесцветными» (301 var(--…)).
    add_editor_style([
        'assets/css/tokens.css',
        'assets/css/fonts.css',
        'assets/css/build.css',
        'assets/css/base.css',
        'assets/css/article.css',
    ]);

    register_nav_menus([
        'primary' => __('Основное меню', 'site2'),
        'footer'  => __('Меню в подвале', 'site2'),
    ]);
});

// 3. Register Block Styles & 15 Gutenberg Patterns
add_action('init', function () {
    // 3.1. Block Styles for Images
    if (function_exists('register_block_style')) {
        register_block_style('core/image', [
            'name'  => 'blueprint',
            'label' => __('Инженерный чертёж', 'site2'),
        ]);
        register_block_style('core/image', [
            'name'  => 'polaroid',
            'label' => __('Лабораторный полароид', 'site2'),
        ]);
        register_block_style('core/image', [
            'name'  => 'washi',
            'label' => __('Со скотчем (Washi)', 'site2'),
        ]);
    }

    // 3.2. Block Patterns Category
    if (function_exists('register_block_pattern_category')) {
        register_block_pattern_category('tochka-plavleniya', [
            'label' => __('ТОЧКА ПЛАВЛЕНИЯ', 'site2'),
        ]);
    }

    // 3.3. Block Patterns (15 complete editorial patterns)
    if (function_exists('register_block_pattern')) {

        // 1. TL;DR Стикер по центру
        register_block_pattern('tochka-plavleniya/tldr-center', [
            'title'       => __('1. Стикер: Главный принцип (TL;DR по центру)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Крафтовый жёлтый стикер с ключевым выводом за 10 секунд', 'site2'),
            'content'     => '<!-- wp:group {"className":"callout-tldr callout tldr"} -->
<div class="wp-block-group callout-tldr callout tldr"><!-- wp:paragraph {"className":"callout-title font-mono text-xs font-bold uppercase tracking-wider text-ink mb-1"} -->
<p class="callout-title font-mono text-xs font-bold uppercase tracking-wider text-ink mb-1">Главный принцип // Регламент 10 секунд</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"font-semibold leading-relaxed m-0"} -->
<p class="font-semibold leading-relaxed m-0">[Сформулируйте ключевой практический вывод операции: проверяемое условие, режим и результат по техническому регламенту конкретной задачи].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
        ]);

        // 2. Стикер на полях с обтеканием
        register_block_pattern('tochka-plavleniya/tldr-aside', [
            'title'       => __('2. Стикер: Заметка на полях (сбоку от текста)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Компактная жёлтая заметка сбоку с мягким обтеканием основного текста', 'site2'),
            'content'     => '<!-- wp:group {"className":"callout-aside"} -->
<div class="wp-block-group callout-aside"><!-- wp:paragraph {"className":"font-mono text-xs font-bold uppercase tracking-wider text-ink mb-1"} -->
<p class="font-mono text-xs font-bold uppercase tracking-wider text-ink mb-1">Заметка на полях</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"text-xs leading-relaxed m-0"} -->
<p class="text-xs leading-relaxed m-0">[Компактная пометка на полях: важный нюанс подготовки, граничные условия применимости или практический совет со ссылкой на документацию].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
        ]);

        // 3. Техника безопасности (Safety First)
        register_block_pattern('tochka-plavleniya/safety-warning', [
            'title'       => __('3. Врезка: Техника безопасности (Safety First)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Оранжевый блок предостережения от термоудара и повреждения чипов', 'site2'),
            'content'     => '<!-- wp:group {"className":"callout-safety"} -->
<div class="wp-block-group callout-safety"><!-- wp:paragraph {"className":"m-0"} -->
<p class="m-0"><strong>Внимание (Техника безопасности):</strong> [Проверенное предупреждение по безопасности или предел термоудара для конкретного компонента с указанием граничных условий и источника из документации].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
        ]);

        // 4. Совет мастера (Pro Tip)
        register_block_pattern('tochka-plavleniya/pro-tip', [
            'title'       => __('4. Врезка: Совет мастера (Pro Tip)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Мятно-зеленая рамка с тонким практическим лайфхаком', 'site2'),
            'content'     => '<!-- wp:group {"className":"callout-pro"} -->
<div class="wp-block-group callout-pro"><!-- wp:paragraph {"className":"m-0"} -->
<p class="m-0"><strong>Инженерная рекомендация:</strong> [Практическая рекомендация мастера с указанием граничных условий применимости под конкретную технологию или тип платы].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
        ]);

        // 5. Стандарт IPC / ГОСТ
        register_block_pattern('tochka-plavleniya/ipc-note', [
            'title'       => __('5. Врезка: Стандарт IPC-A-610 / ГОСТ', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Строгий нормативный блок со ссылкой на отраслевой регламент', 'site2'),
            'content'     => '<!-- wp:group {"className":"callout-ipc"} -->
<div class="wp-block-group callout-ipc"><!-- wp:paragraph {"className":"m-0"} -->
<p class="m-0"><strong>Стандарт IPC / ГОСТ:</strong> [Нормативное требование стандарта к проверяемому соединению со ссылкой на класс приемки Class 1/2/3 и пункт спецификации].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
        ]);

        // 6. Картинка слева + Текст справа
        register_block_pattern('tochka-plavleniya/media-text-left', [
            'title'       => __('6. Иллюстрация слева + Текст справа', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Двухколоночный блок с фото детали и пояснительным текстом', 'site2'),
            'content'     => '<!-- wp:media-text {"mediaPosition":"left","mediaType":"image","className":"my-6"} -->
<div class="wp-block-media-text alignwide is-stacked-on-mobile my-6"><figure class="wp-block-media-text__media"><img src="data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 400 250\' width=\'400\' height=\'250\'%3E%3Crect width=\'400\' height=\'250\' fill=\'%23f5f3ee\' stroke=\'%23d1cbbe\' stroke-width=\'2\' stroke-dasharray=\'4\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'monospace\' font-size=\'12\' fill=\'%23706d64\'%3E%5B%D0%A7%D0%95%D0%A0%D0%A2%D0%81%D0%96 // %D0%97%D0%90%D0%93%D0%A0%D0%A3%D0%97%D0%98%D0%A2%D0%95 %D0%A4%D0%9E%D0%A2%D0%9E%5D%3C/text%3E%3C/svg%3E" alt="Контроль пайки под микроскопом"/></figure><div class="wp-block-media-text__content"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">[Контроль паяного соединения под микроскопом]</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>[Критерии визуального контроля галтели по IPC-A-610G для конкретного сплава: вогнутый мениск, угол смачивания и допустимый вид поверхности (глянцевый для ПОС-61 / полуматовый сатиновый для бессвинцовых сплавов)].</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->',
        ]);

        // 7. Текст слева + Картинка справа
        register_block_pattern('tochka-plavleniya/media-text-right', [
            'title'       => __('7. Текст слева + Иллюстрация справа', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Зеркальный блок для чередования ритма в лонгриде', 'site2'),
            'content'     => '<!-- wp:media-text {"mediaPosition":"right","mediaType":"image","className":"my-6"} -->
<div class="wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile my-6"><figure class="wp-block-media-text__media"><img src="data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 400 250\' width=\'400\' height=\'250\'%3E%3Crect width=\'400\' height=\'250\' fill=\'%23f5f3ee\' stroke=\'%23d1cbbe\' stroke-width=\'2\' stroke-dasharray=\'4\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'monospace\' font-size=\'12\' fill=\'%23706d64\'%3E%5B%D0%A7%D0%95%D0%A0%D0%A2%D0%81%D0%96 // %D0%97%D0%90%D0%93%D0%A0%D0%A3%D0%97%D0%98%D0%A2%D0%95 %D0%A4%D0%9E%D0%A2%D0%9E%5D%3C/text%3E%3C/svg%3E" alt="Посадка шаров BGA"/></figure><div class="wp-block-media-text__content"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">[Позиционирование и контроль монтажа]</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>[Технологические указания по монтажу конкретного компонента: позиционирование, высота сопла инструмента и интенсивность воздушного потока].</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->',
        ]);

        // 8. Сравнение «БРАК vs НОРМА (ДО / ПОСЛЕ)»
        register_block_pattern('tochka-plavleniya/compare-defect-norm', [
            'title'       => __('8. Сравнение: БРАК vs НОРМА (ДО / ПОСЛЕ)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Две колонки с цветными бейджами для наглядного контроля дефектов пайки', 'site2'),
            'content'     => '<!-- wp:columns {"className":"compare-grid"} -->
<div class="wp-block-columns compare-grid"><!-- wp:column {"className":"compare-col compare-card defect"} -->
<div class="wp-block-column compare-col compare-card defect"><!-- wp:paragraph -->
<p><span class="badge-defect">✕ ДЕФЕКТ (БРАК)</span></p>
<!-- /wp:paragraph --><!-- wp:image {"className":"my-2"} -->
<figure class="wp-block-image my-2"><img src="data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 300 200\' width=\'300\' height=\'200\'%3E%3Crect width=\'300\' height=\'200\' fill=\'%23fef2f2\' stroke=\'%23f87171\' stroke-width=\'2\' stroke-dasharray=\'4\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'monospace\' font-size=\'11\' fill=\'%23b91c1c\'%3E%5B%D0%A4%D0%9E%D0%A2%D0%9E %D0%94%D0%95%D0%A4%D0%95%D0%9A%D0%A2%D0%90%5D%3C/text%3E%3C/svg%3E" alt="Дефект пайки"/></figure>
<!-- /wp:image --><!-- wp:paragraph {"className":"text-xs text-ink-muted leading-relaxed"} -->
<p class="text-xs text-ink-muted leading-relaxed"><strong>[Признаки брака соединения]:</strong> [Описание недопустимых дефектов по IPC-A-610: холодная пайка, каверны, мостики припоя].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --><!-- wp:column {"className":"compare-col compare-card norm"} -->
<div class="wp-block-column compare-col compare-card norm"><!-- wp:paragraph -->
<p><span class="badge-norm">✓ ГОСТ / IPC-A-610</span></p>
<!-- /wp:paragraph --><!-- wp:image {"className":"my-2"} -->
<figure class="wp-block-image my-2"><img src="data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 300 200\' width=\'300\' height=\'200\'%3E%3Crect width=\'300\' height=\'200\' fill=\'%23f0fdf4\' stroke=\'%234ade80\' stroke-width=\'2\' stroke-dasharray=\'4\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'monospace\' font-size=\'11\' fill=\'%2315803d\'%3E%5B%D0%A4%D0%9E%D0%A2%D0%9E %D0%9D%D0%9E%D0%A0%D0%9C%D0%AB%5D%3C/text%3E%3C/svg%3E" alt="Норма пайки"/></figure>
<!-- /wp:image --><!-- wp:paragraph {"className":"text-xs text-ink-muted leading-relaxed"} -->
<p class="text-xs text-ink-muted leading-relaxed"><strong>[Критерии нормы Class 2/3]:</strong> [Описание признаков качественного соединения: вогнутый мениск, угол контакта &lt; 30°, смачивание контактных площадок].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->',
        ]);

        // 9. Векторная схема термопрофиля
        register_block_pattern('tochka-plavleniya/thermal-profile-svg', [
            'title'       => __('9. График: Инженерная кривая термопрофиля (SVG)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Инженерная кривая 4 фаз нагрева с отметками Preheat, Soak, Reflow и Cooling', 'site2'),
            'content'     => '<!-- wp:html -->
<div class="sketch-frame p-4 sm:p-6 my-6 relative overflow-hidden bg-card border border-paper-border rounded-lg shadow-xs">
  <div class="font-hand text-xl font-bold text-ink mb-3 flex items-center gap-2">
    <svg class="tp-icon w-4 h-4 text-accent" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
    <span>Схема нагрева: [Пример нормированного термопрофиля оплавления]</span>
  </div>
  <div class="w-full overflow-x-auto">
    <svg viewBox="0 0 540 220" width="100%" height="auto" fill="none" class="max-w-full">
      <rect width="540" height="220" rx="8" class="fill-paper-subtle stroke-paper-border" stroke-width="1.5"/>
      <line x1="40" y1="180" x2="500" y2="180" stroke="currentColor" stroke-opacity="0.2" stroke-width="1.5" stroke-dasharray="4 4"/>
      <line x1="40" y1="110" x2="500" y2="110" stroke="currentColor" stroke-opacity="0.2" stroke-width="1" stroke-dasharray="3 4"/>
      <line x1="40" y1="50" x2="500" y2="50" stroke="currentColor" stroke-opacity="0.2" stroke-width="1" stroke-dasharray="2 4"/>
      <path d="M40 180 Q120 160 180 110 T320 50 T440 80 T500 180" stroke="var(--color-ink,#1c1917)" stroke-width="3" stroke-linecap="round" fill="none"/>
      <circle cx="180" cy="110" r="6" fill="#fde047" stroke="var(--color-ink,#1c1917)" stroke-width="2"/>
      <circle cx="320" cy="50" r="6" fill="var(--color-accent,#ea580c)" stroke="var(--color-ink,#1c1917)" stroke-width="2"/>
      <circle cx="440" cy="80" r="6" fill="#2dd4bf" stroke="var(--color-ink,#1c1917)" stroke-width="2"/>
      <text x="110" y="96" font-family="Caveat,cursive" font-size="18" font-weight="700" fill="var(--color-ink,#1c1917)">Preheat (150°C)</text>
      <text x="270" y="36" font-family="Caveat,cursive" font-size="19" font-weight="700" fill="var(--color-accent,#ea580c)">Peak Reflow (242°C) ★</text>
      <text x="430" y="115" font-family="Caveat,cursive" font-size="18" font-weight="700" fill="var(--color-ink,#1c1917)">Cooling (6°C/s)</text>
      <text x="40" y="202" font-family="JetBrains Mono,monospace" font-size="11" fill="currentColor" fill-opacity="0.6">0s</text>
      <text x="165" y="202" font-family="JetBrains Mono,monospace" font-size="11" fill="currentColor" fill-opacity="0.6">90s (Soak)</text>
      <text x="305" y="202" font-family="JetBrains Mono,monospace" font-size="11" fill="currentColor" fill-opacity="0.6">210s (TAL)</text>
      <text x="470" y="202" font-family="JetBrains Mono,monospace" font-size="11" fill="currentColor" fill-opacity="0.6">300s</text>
    </svg>
  </div>
  <div class="mt-2 text-xs font-mono text-ink-muted flex flex-col sm:flex-row sm:items-center justify-between gap-1">
    <span>Рис. Учебный пример термопрофиля оплавления SAC305 (Liquidus 217°C) при толщине платы &gt; 1.6 мм</span>
    <span>IPC/JEDEC J-STD-020D (Справочный пример)</span>
  </div>
</div>
<!-- /wp:html -->',
        ]);

        // 10. Пошаговый регламент операции (100% валидный синтаксис)
        register_block_pattern('tochka-plavleniya/step-procedure', [
            'title'       => __('10. Пошаговый регламент операции (Шаги 1–4)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Карточки пошагового технологического процесса с цветными бейджами', 'site2'),
            'content'     => '<!-- wp:group {"className":"step-card"} -->
<div class="wp-block-group step-card"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><span class="step-badge step-badge-yellow">ШАГ 01</span> Подготовка и фиксация</h4>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>[Описание подготовительного этапа: очистка контактных площадок, механическая фиксация и предварительный подогрев с указанием граничных температур по технологической карте платы].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"step-card"} -->
<div class="wp-block-group step-card"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><span class="step-badge step-badge-orange">ШАГ 02</span> Нанесение флюса и нагрев</h4>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>[Описание операции пайки/монтажа: тип флюса, дозирование припоя, режим термоинструмента и дистанция сопла под конкретный компонент].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"step-card"} -->
<div class="wp-block-group step-card"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><span class="step-badge step-badge-mint">ШАГ 03</span> Охлаждение и контроль</h4>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>[Описание фазы кристаллизации и контроля качества соединения: визуальные признаки правильного мениска смачивания и отсутствие механических вибраций до полного застывания].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
        ]);

        // 11. Что понадобится (Оснастка и инструмент)
        register_block_pattern('tochka-plavleniya/tools-needed', [
            'title'       => __('11. Карточка: Оснастка и материалы (Что понадобится)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Стартовый блок со списком оборудования и расходников', 'site2'),
            'content'     => '<!-- wp:group {"className":"tools-box"} -->
<div class="wp-block-group tools-box"><!-- wp:heading {"level":4,"className":"font-mono text-xs uppercase tracking-wider text-ink pb-2 border-b border-paper-border flex items-center justify-between"} -->
<h4 class="wp-block-heading font-mono text-xs uppercase tracking-wider text-ink pb-2 border-b border-paper-border flex items-center justify-between"><span>Оснастка и материалы</span><span class="text-accent text-xs font-bold">СПЕЦИФИКАЦИЯ</span></h4>
<!-- /wp:heading --><!-- wp:paragraph {"className":"text-xs font-mono leading-loose mt-2"} -->
<p class="text-xs font-mono leading-loose mt-2">▸ <strong>[Оборудование 1]:</strong> [Модель термоинструмента и рабочее сопло/жало]<br>▸ <strong>[Оснастка 2]:</strong> [Нижний подогрев / термостол с датчиком обратной связи]<br>▸ <strong>[Флюс / Паста]:</strong> [Тип флюса по J-STD-004 и марка под задачу]<br>▸ <strong>[Расходный материал]:</strong> [Марка припоя по ГОСТ/ISO и вспомогательные средства]</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
        ]);

        // 12. Чек-лист готовности перед пайкой
        register_block_pattern('tochka-plavleniya/checklist-preflight', [
            'title'       => __('12. Чек-лист: Инженерный контроль перед операцией', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Список обязательных проверок с отметками готовности', 'site2'),
            'content'     => '<!-- wp:group {"className":"checklist-box"} -->
<div class="wp-block-group checklist-box"><!-- wp:heading {"level":4,"className":"font-mono text-xs uppercase tracking-wider font-bold text-ink mb-3"} -->
<h4 class="wp-block-heading font-mono text-xs uppercase tracking-wider font-bold text-ink mb-3">Контрольный чек-лист перед включением</h4>
<!-- /wp:heading --><!-- wp:paragraph {"className":"checklist-item"} -->
<p class="checklist-item"><span class="check-icon">[✓]</span> <strong>Влагосодержание чипов:</strong> [Проверка чувствительности к влаге MSL по J-STD-020, предварительная сушка при необходимости].</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"checklist-item"} -->
<p class="checklist-item"><span class="check-icon">[✓]</span> <strong>Антистатическая защита ESD:</strong> [Заземление рабочего места, антистатический браслет и инструмент по стандарту].</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"checklist-item"} -->
<p class="checklist-item"><span class="check-icon">[✓]</span> <strong>Термоконтроль:</strong> [Установка и калибровка термодатчика в зоне пайки по технологической карте].</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"checklist-item"} -->
<p class="checklist-item"><span class="check-icon">[✓]</span> <strong>Срок годности материалов:</strong> [Проверка срока годности флюса, отсутствие расслоения и осадка].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
        ]);

        // 13. BOM-таблица параметров
        register_block_pattern('tochka-plavleniya/bom-table', [
            'title'       => __('13. Таблица: Параметры режимов (BOM-table)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Инженерная спецификация режимов, температур и допусков', 'site2'),
            'content'     => '<!-- wp:table {"className":"bom-table"} -->
<figure class="wp-block-table bom-table"><table class="has-fixed-layout"><thead><tr><th>Параметр / Инструмент</th><th>Режим техпроцесса</th><th>Допуск / Спецификация</th></tr></thead><tbody><tr><td>[Название термоинструмента]</td><td>[Рабочая уставка температуры]</td><td>[Допустимый коридор по ТУ]</td></tr><tr><td>[Подогрев платы / термостол]</td><td>[Температура предварительного прогрева]</td><td>[Датчик контроля / термопара]</td></tr><tr><td>[Флюс / паяльная паста]</td><td>[Классификация по J-STD-004]</td><td>[Метод удаления остатков]</td></tr><tr><td>[Время контакта / выдержка]</td><td>[Длительность пайки (сек)]</td><td>[Стандарт IPC / ГОСТ]</td></tr></tbody></table></figure>
<!-- /wp:table -->',
        ]);

        // 14. FAQ / Блок частых вопросов
        register_block_pattern('tochka-plavleniya/faq-accordion', [
            'title'       => __('14. Блок: Частые вопросы и ошибки (FAQ)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Карточки вопросов и ответов для читателей и поисковых сниппетов', 'site2'),
            'content'     => '<!-- wp:group {"className":"space-y-3 my-6"} -->
<div class="wp-block-group space-y-3 my-6"><!-- wp:group {"className":"faq-item"} -->
<div class="wp-block-group faq-item"><!-- wp:heading {"level":4,"className":"text-base font-bold text-ink mb-1"} -->
<h4 class="wp-block-heading text-base font-bold text-ink mb-1">[Вопрос 1: Допустимый температурный предел для конкретного компонента]</h4>
<!-- /wp:heading --><!-- wp:paragraph {"className":"text-sm text-ink-muted leading-relaxed m-0"} -->
<p class="text-sm text-ink-muted leading-relaxed m-0">[Ответ: Укажите проверенный пиковый температурный предел и максимальное время воздействия со ссылкой на документацию производителя (datasheet) или стандарт J-STD-020].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"faq-item"} -->
<div class="wp-block-group faq-item"><!-- wp:heading {"level":4,"className":"text-base font-bold text-ink mb-1"} -->
<h4 class="wp-block-heading text-base font-bold text-ink mb-1">[Вопрос 2: Время нахождения припоя над ликвидусом (TAL)]</h4>
<!-- /wp:heading --><!-- wp:paragraph {"className":"text-sm text-ink-muted leading-relaxed m-0"} -->
<p class="text-sm text-ink-muted leading-relaxed m-0">[Ответ: Укажите расчетный диапазон времени над ликвидусом для используемого сплава и паяльной пасты с учетом теплоемкости платы].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
        ]);

        // 15. Заметка на полях со стрелочкой (Marginalia)
        register_block_pattern('tochka-plavleniya/marginalia-note', [
            'title'       => __('15. Заметка на полях (Marginalia со стрелкой)', 'site2'),
            'categories'  => ['tochka-plavleniya'],
            'description' => __('Фирменная рукописная пометка от руки со скетчевой стрелочкой', 'site2'),
            'content'     => '<!-- wp:group {"className":"marginalia-box"} -->
<div class="wp-block-group marginalia-box"><!-- wp:paragraph {"className":"marginalia-text"} -->
<p class="marginalia-text">[Важная инженерная деталь: практический нюанс операции с обоснованием физического механизма процесса под конкретный компонент].</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
        ]);
    }
});

// 4. Fail-safe Routing & Fallbacks (Zero-404 Architecture)
add_action('template_redirect', function () {
    $uri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    $path = trim($uri, '/');

    // 4.0. Legacy / Direct category.php requests -> 301 Permanent Redirect to canonical WP category
    if ($path === 'category.php' || $path === 'category') {
        $slug = $_GET['slug'] ?? '';
        if (!empty($slug)) {
            $cat_map = [
                'start'         => 'старт-и-база',
                'старт-и-база' => 'старт-и-база',
                'start-i-baza'  => 'старт-и-база',
                'praktika'      => 'praktika',
                'oshibki'       => 'oshibki',
                'materialy'     => 'materialy'
            ];
            $target_slug = $cat_map[$slug] ?? $slug;
            $cat = function_exists('get_category_by_slug') ? get_category_by_slug($target_slug) : null;
            if (!$cat && function_exists('get_category_by_slug')) {
                $cat = get_category_by_slug($slug);
            }
            if ($cat && !is_wp_error($cat) && function_exists('get_category_link')) {
                wp_safe_redirect(get_category_link($cat->term_id), 301);
                exit;
            }
            if (function_exists('home_url')) {
                wp_safe_redirect(home_url('/category/' . urlencode($target_slug) . '/'), 301);
                exit;
            }
        }
    }

    if (is_404()) {
        // 4.1. Root URL
        if ($path === '' || empty($path)) {
            status_header(200);
            require __DIR__ . '/index.php';
            exit;
        }

        // 4.2. Interactive Workbench
        if ($path === 'interactive' || $path === 'interactive.php') {
            status_header(200);
            require __DIR__ . '/page-interactive.php';
            exit;
        }

        // 4.3. Legal Pages
        if ($path === 'privacy' || $path === 'privacy.php') {
            status_header(200);
            require __DIR__ . '/privacy.php';
            exit;
        }
        if ($path === 'terms' || $path === 'terms.php') {
            status_header(200);
            require __DIR__ . '/terms.php';
            exit;
        }
        if ($path === 'cookies' || $path === 'cookies.php') {
            status_header(200);
            require __DIR__ . '/cookies.php';
            exit;
        }
    }
});

// 4.4. Clean Typography: Disable WP Emoji to SVG conversion to avoid duplicated icons & preserve clean text
add_action('init', function () {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
});

// 5. Disable WordPress comments (Zero-PII / 152-ФЗ compliance)
add_filter('comments_open', '__return_false', 20, 2);
add_filter('pings_open', '__return_false', 20, 2);
add_filter('comments_array', '__return_empty_array', 10, 2);

// 6. Подключение модуля импорта базы знаний и регламентов ТЧП
require_once __DIR__ . '/includes/demo-importer.php';

// 8. Резервная отдача GEO и LLM файлов (llms.txt, llms-full.txt, robots.txt) через WordPress
add_action('init', function () {
    $uri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    $req = trim($uri, '/');
    if ($req === 'llms.txt' || $req === 'llms-full.txt' || $req === 'robots.txt') {
        $theme_file = function_exists('get_template_directory') ? get_template_directory() . '/' . $req : __DIR__ . '/' . $req;
        $root_file  = defined('ABSPATH') ? ABSPATH . $req : null;
        $target     = ($root_file && file_exists($root_file)) ? $root_file : (file_exists($theme_file) ? $theme_file : null);
        if ($target) {
            header('Content-Type: text/plain; charset=utf-8');
            header('X-Robots-Tag: all');
            readfile($target);
            exit;
        }
    }
});

/**
 * GEO: если rich-snippet Rank Math активен (тема свою схему не выводит),
 * добавляем факты из полей tchp-content прямо в его JSON-LD:
 * припой/температуры/стандарт (additionalProperty), источники (citation),
 * редакционную проверку (reviewedBy).
 */
add_filter('rank_math/json_ld', function ($data, $jsonld = null) {
    if (!is_array($data) || !function_exists('is_singular') || !is_singular()) {
        return $data;
    }
    if (!function_exists('tchp_get_geo_facts')) {
        return $data;
    }
    $post_id = function_exists('get_queried_object_id') ? (int) get_queried_object_id() : 0;
    if ($post_id <= 0) {
        return $data;
    }
    $facts = tchp_get_geo_facts($post_id);
    if (empty($facts['additionalProperty']) && empty($facts['citation']) && empty($facts['reviewedBy'])) {
        return $data;
    }
    $enrich = static function (array &$node) use ($facts) {
        $type  = $node['@type'] ?? '';
        $types = is_array($type) ? $type : [$type];
        if (!array_intersect($types, ['Article', 'TechArticle', 'BlogPosting', 'NewsArticle'])) {
            return false;
        }
        if (!empty($facts['additionalProperty'])) {
            $existing = isset($node['additionalProperty']) && is_array($node['additionalProperty']) ? $node['additionalProperty'] : [];
            $node['additionalProperty'] = array_merge($existing, $facts['additionalProperty']);
        }
        if (!empty($facts['citation']) && empty($node['citation'])) {
            $node['citation'] = $facts['citation'];
        }
        if (!empty($facts['reviewedBy'])) {
            $node['reviewedBy'] = $facts['reviewedBy'];
        }
        if (!empty($facts['keywords']) && empty($node['keywords'])) {
            $node['keywords'] = implode(', ', $facts['keywords']);
        }
        return true;
    };
    foreach ($data as $key => $node) {
        if (!is_array($node)) {
            continue;
        }
        if ($enrich($data[$key])) {
            return $data;
        }
        if (!empty($node['@graph']) && is_array($node['@graph'])) {
            foreach ($node['@graph'] as $gkey => $gnode) {
                if (is_array($gnode) && $enrich($data[$key]['@graph'][$gkey])) {
                    return $data;
                }
            }
        }
    }
    return $data;
}, 99, 2);

